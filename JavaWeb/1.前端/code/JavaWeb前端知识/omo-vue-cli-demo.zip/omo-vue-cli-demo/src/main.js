// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'         // 导入Vue模块，才可以使用Vue的内容
import App from './App'       // 导入当前目录下App.vue组件文件
import router from './router' // 导入当前目录下路由index.js文件,注意，由于router目录下路由默认文件名为 index.js ，因此可以省略
// 导入element-ui相关
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

// 使用elementUI
Vue.use(ElementUI);

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,  // 路由  router:router，
  components: { App }, // 引入一个组件App
  template: '<App/>' // template定义页面HTML模板,来源App.vue组件中的内容,再将App.vue组件中的内容渲染到"#app"元素中
})

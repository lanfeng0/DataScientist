// 导入vue模块
import Vue from 'vue'
// 导入路由模块
import Router from 'vue-router'
// 导入HelloWorld组件
import HelloWorld from '@/components/HelloWorld'
// 导入Article组件
import Article from '@/components/Article'
import User from '@/components/User'

// 使用路由功能
Vue.use(Router)

export default new Router({
  mode: 'history', // 去除路径上的#
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/article',
      name: 'Article',
      component: Article
    },
    {
      path: '/user',
      name: 'User',
      component: User
    }
  ]
})

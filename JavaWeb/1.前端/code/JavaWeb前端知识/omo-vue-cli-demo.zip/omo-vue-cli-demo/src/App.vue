<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <h1>App.vue</h1>
    <p id="">
       <router-link to="/Article">文章管理</router-link>
       <router-link to="/User">用户管理</router-link>
    </p>
    <hr/>
    <!-- 路由的出口,匹配到的组件内容将渲染在此处 -->
    <router-view/>

  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

</style>

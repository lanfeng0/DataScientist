<template>
   <div>
     <h1>{{ msg }}</h1>
     <!-- 未来表格 -->
     <el-container>
     	<el-header>文章列表</el-header>

     	<div style="margin-top: 15px;margin-bottom: 10px;">
     	  <el-input placeholder="请输入文章标题关键字" v-model="input" style="width: 20%;">
     		<el-button slot="append" icon="el-icon-search"  @click="search()"></el-button>
     	  </el-input>
     	 </div>

     	<el-main>
     		<el-table :data="tableData" style="width: 100%;">
     			<el-table-column prop="articleId" label="文章编号" width="180">
     			</el-table-column>
     			<el-table-column prop="articleTitle" label="文章标题" width="180">
     			</el-table-column>
     			<el-table-column prop="articleContent" label="文章内容" width="180">
     			</el-table-column>
     			<el-table-column prop="clickCount" label="点击量" width="180">
     			</el-table-column>
     			<el-table-column prop="publishDatetime" label="发布时间" width="180">
     			</el-table-column>
     			<el-table-column prop="userInfo.userName" label="作者" width="180">
     			</el-table-column>

     			<el-table-column prop="address" label="操作">
     				<template slot-scope="scope">
     					<el-button type="primary" icon="el-icon-edit" circle></el-button>
     					<el-button type="danger" icon="el-icon-delete" circle @click="deleteById(scope.row.articleId)"></el-button>
     				</template>
     			</el-table-column>
     		</el-table>
     		<div class="block" style="margin-top: 15px;margin-bottom: 10px;">
     		    <el-pagination
     		      @size-change="handleSizeChange"
     		      @current-change="handleCurrentChange"
     		      :current-page="currentPage"
     		      :page-sizes="pageSizes"
     		      :page-size="pageSize"
     		      layout="total, sizes, prev, pager, next, jumper"
     		      :total="total">
     		    </el-pagination>
     		  </div>
     	</el-main>
     </el-container>
   </div>
</template>

<script>
 // 导入axios
 import axios from 'axios';
 // 导入qs
 import qs from 'qs';

 export default {
    name: 'Article',
    data() {
      return {
        msg: '文章模块管理页',
        tableData: [],
        pageSizes:[2,4,6,8],
        currentPage: 1,
        pageSize: 2,
        total:0,
        input:""

      }
    },
    mounted:function(){
    	this.getArticleList(this.currentPage,this.pageSize);
    },
    methods:{
    	getArticleList:function(pageNum,pageSize){
    		// 发送axios请求服务器文章数据
    		axios({
    			method:"GET",
    			url:"http://192.168.4.6:8888/article/page",
    		    params:{
    				articleTitle:this.input,
    				pageNum: pageNum,
    				pageSize: pageSize
    			}
    		}).then(response=>{

    			// 将响应的数据 赋值 给vue实例的属性
    			// 判断是否有数据
    			if(response.data.data.list != null){
    				// 表格数据
    				this.tableData = response.data.data.list;
    				// 分页数据
    				this.currentPage = response.data.data.pageNum;
    				this.pageSize = response.data.data.pageSize;
    				this.total = response.data.data.total;
    			}else{
    				// 表格数据
    				this.tableData = [];
    				// 分页数据
    				this.currentPage = 0;
    				this.total = 0;
    			}

    		}).catch(error=>{
    			alert("axios请求失败!")
    		})
    	},
    	deleteById:function(articleId){
    		// 发起axios请求删除
    		axios({
    			method:"GET",
    			url:"http://192.168.4.6:8888/article/deleteById",
    			params:{
    				articleId:articleId
    			}
    		}).then(response=>{
    			// 删除之后重新渲染数据
    			// 调用method中定义的方法
    			this.getArticleList(this.currentPage,this.pageSize);
    		}).catch(error=>{
    			alert("axios异步请求失败!")
    		})
    	},
        handleSizeChange(val) {
                // console.log(`每页 ${val} 条`);
    			this.getArticleList(this.currentPage,val);
        },
        handleCurrentChange(val) {
                // console.log(`当前页: ${val}`);
    			this.getArticleList(val,this.pageSize);
         },
    	 search:function(){
    		 this.getArticleList(this.currentPage,this.pageSize);
    	 }
    }

  }
</script>

<style>
  h1{
    font-family: "微软雅黑";
  }
</style>

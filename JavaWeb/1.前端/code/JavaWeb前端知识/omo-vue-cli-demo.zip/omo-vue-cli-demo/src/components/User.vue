<template>
   <div>
     <h1>{{ msg }}</h1>
     <!-- 未来表格 --> 
   </div>
</template>

<script>
 export default {
    name: 'Article',
    data() {
      return {
        msg: '用户模块管理页'
      }
    },
   
    }
</script>

<style>
  h1{
    font-family: "微软雅黑";
  }
</style>

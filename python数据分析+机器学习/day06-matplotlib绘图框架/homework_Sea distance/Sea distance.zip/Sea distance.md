
# 城市气候与海洋的关系研究

导入包


```python
import numpy as np
import pandas as pd
from pandas import Series,DataFrame
import matplotlib.pyplot as plt
%matplotlib inline
```

导入数据各个海滨城市数据


```python
ferrara1 = pd.read_csv('./ferrara_150715.csv')
ferrara2 = pd.read_csv('./ferrara_250715.csv')
ferrara3 = pd.read_csv('./ferrara_270615.csv')
ferrara = pd.concat([ferrara1,ferrara2,ferrara3],ignore_index=True) 
ferrara.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>30.44</td>
      <td>60</td>
      <td>1011.0</td>
      <td>moderate rain</td>
      <td>1436863096</td>
      <td>1.03</td>
      <td>180.0</td>
      <td>Ferrara</td>
      <td>2015-07-14 10:38:16</td>
      <td>47</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>31.40</td>
      <td>58</td>
      <td>1011.0</td>
      <td>moderate rain</td>
      <td>1436866685</td>
      <td>1.54</td>
      <td>135.0</td>
      <td>Ferrara</td>
      <td>2015-07-14 11:38:05</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>31.95</td>
      <td>54</td>
      <td>1011.0</td>
      <td>moderate rain</td>
      <td>1436870387</td>
      <td>0.51</td>
      <td>113.0</td>
      <td>Ferrara</td>
      <td>2015-07-14 12:39:47</td>
      <td>47</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>32.06</td>
      <td>50</td>
      <td>1011.0</td>
      <td>moderate rain</td>
      <td>1436873989</td>
      <td>2.06</td>
      <td>90.0</td>
      <td>Ferrara</td>
      <td>2015-07-14 13:39:49</td>
      <td>47</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>32.63</td>
      <td>49</td>
      <td>1010.0</td>
      <td>moderate rain</td>
      <td>1436877535</td>
      <td>1.54</td>
      <td>68.0</td>
      <td>Ferrara</td>
      <td>2015-07-14 14:38:55</td>
      <td>47</td>
    </tr>
  </tbody>
</table>
</div>




```python
torino1 = pd.read_csv('./torino_150715.csv')
torino2 = pd.read_csv('./torino_250715.csv')
torino3 = pd.read_csv('./torino_270615.csv')
torino = pd.concat([torino1,torino2,torino3],ignore_index=True) 
torino.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>28.34</td>
      <td>65</td>
      <td>1017</td>
      <td>Sky is Clear</td>
      <td>1436863109</td>
      <td>3.1</td>
      <td>20</td>
      <td>Torino</td>
      <td>2015-07-14 10:38:29</td>
      <td>357</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>29.25</td>
      <td>65</td>
      <td>1017</td>
      <td>Sky is Clear</td>
      <td>1436866696</td>
      <td>3.1</td>
      <td>80</td>
      <td>Torino</td>
      <td>2015-07-14 11:38:16</td>
      <td>357</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>30.40</td>
      <td>58</td>
      <td>1017</td>
      <td>Sky is Clear</td>
      <td>1436870399</td>
      <td>2.6</td>
      <td>100</td>
      <td>Torino</td>
      <td>2015-07-14 12:39:59</td>
      <td>357</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>31.37</td>
      <td>54</td>
      <td>1017</td>
      <td>Sky is Clear</td>
      <td>1436874005</td>
      <td>2.1</td>
      <td>90</td>
      <td>Torino</td>
      <td>2015-07-14 13:40:05</td>
      <td>357</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>32.59</td>
      <td>45</td>
      <td>1016</td>
      <td>few clouds</td>
      <td>1436877558</td>
      <td>2.1</td>
      <td>120</td>
      <td>Torino</td>
      <td>2015-07-14 14:39:18</td>
      <td>357</td>
    </tr>
  </tbody>
</table>
</div>




```python
mantova1 = pd.read_csv('./mantova_150715.csv')
mantova2 = pd.read_csv('./mantova_250715.csv')
mantova3 = pd.read_csv('./mantova_270615.csv')
mantova = pd.concat([mantova1,mantova2,mantova3],ignore_index=True) 
mantova.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>28.66</td>
      <td>51</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436863113</td>
      <td>2.1</td>
      <td>140</td>
      <td>Mantova</td>
      <td>2015-07-14 10:38:33</td>
      <td>121</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>30.10</td>
      <td>45</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436866700</td>
      <td>2.1</td>
      <td>0</td>
      <td>Mantova</td>
      <td>2015-07-14 11:38:20</td>
      <td>121</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>30.14</td>
      <td>42</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436870406</td>
      <td>2.1</td>
      <td>170</td>
      <td>Mantova</td>
      <td>2015-07-14 12:40:06</td>
      <td>121</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>30.74</td>
      <td>45</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436874012</td>
      <td>1.5</td>
      <td>0</td>
      <td>Mantova</td>
      <td>2015-07-14 13:40:12</td>
      <td>121</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>31.22</td>
      <td>38</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436877561</td>
      <td>1.5</td>
      <td>180</td>
      <td>Mantova</td>
      <td>2015-07-14 14:39:21</td>
      <td>121</td>
    </tr>
  </tbody>
</table>
</div>




```python
milano1 = pd.read_csv('./milano_150715.csv')
milano2 = pd.read_csv('./milano_250715.csv')
milano3 = pd.read_csv('./milano_270615.csv')
milano = pd.concat([milano1,milano2,milano3],ignore_index=True) 
milano.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>28.57</td>
      <td>54</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436863175</td>
      <td>2.1</td>
      <td>100</td>
      <td>Milano</td>
      <td>2015-07-14 10:39:35</td>
      <td>250</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>29.74</td>
      <td>48</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436866758</td>
      <td>2.6</td>
      <td>0</td>
      <td>Milano</td>
      <td>2015-07-14 11:39:18</td>
      <td>250</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>31.12</td>
      <td>48</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436870509</td>
      <td>2.6</td>
      <td>140</td>
      <td>Milano</td>
      <td>2015-07-14 12:41:49</td>
      <td>250</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>32.16</td>
      <td>45</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436874098</td>
      <td>2.1</td>
      <td>0</td>
      <td>Milano</td>
      <td>2015-07-14 13:41:38</td>
      <td>250</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>33.59</td>
      <td>43</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436877644</td>
      <td>3.1</td>
      <td>80</td>
      <td>Milano</td>
      <td>2015-07-14 14:40:44</td>
      <td>250</td>
    </tr>
  </tbody>
</table>
</div>




```python
ravenna1 = pd.read_csv('./ravenna_150715.csv')
ravenna2 = pd.read_csv('./ravenna_250715.csv')
ravenna3 = pd.read_csv('./ravenna_270615.csv')
ravenna = pd.concat([ravenna1,ravenna2,ravenna3],ignore_index=True)
ravenna.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>29.10</td>
      <td>74</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436863177</td>
      <td>3.10</td>
      <td>10.0</td>
      <td>Ravenna</td>
      <td>2015-07-14 10:39:37</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>29.51</td>
      <td>74</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436866759</td>
      <td>3.60</td>
      <td>20.0</td>
      <td>Ravenna</td>
      <td>2015-07-14 11:39:19</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>29.63</td>
      <td>70</td>
      <td>1016</td>
      <td>moderate rain</td>
      <td>1436870511</td>
      <td>3.60</td>
      <td>40.0</td>
      <td>Ravenna</td>
      <td>2015-07-14 12:41:51</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>30.17</td>
      <td>37</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436874106</td>
      <td>4.63</td>
      <td>90.0</td>
      <td>Ravenna</td>
      <td>2015-07-14 13:41:46</td>
      <td>8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>30.45</td>
      <td>34</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436877646</td>
      <td>3.08</td>
      <td>87.0</td>
      <td>Ravenna</td>
      <td>2015-07-14 14:40:46</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
</div>




```python
asti1 = pd.read_csv('./asti_150715.csv')
asti2 = pd.read_csv('./asti_250715.csv')
asti3 = pd.read_csv('./asti_270615.csv')
asti = pd.concat([asti1,asti2,asti3],ignore_index=True)
asti.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>28.05</td>
      <td>66</td>
      <td>1014</td>
      <td>Sky is Clear</td>
      <td>1436863176</td>
      <td>2.57</td>
      <td>42.501</td>
      <td>Asti</td>
      <td>2015-07-14 10:39:36</td>
      <td>315</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>29.51</td>
      <td>64</td>
      <td>1014</td>
      <td>Sky is Clear</td>
      <td>1436866759</td>
      <td>1.54</td>
      <td>263.000</td>
      <td>Asti</td>
      <td>2015-07-14 11:39:19</td>
      <td>315</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>30.39</td>
      <td>58</td>
      <td>1017</td>
      <td>Sky is Clear</td>
      <td>1436870510</td>
      <td>2.60</td>
      <td>100.000</td>
      <td>Asti</td>
      <td>2015-07-14 12:41:50</td>
      <td>315</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>31.10</td>
      <td>54</td>
      <td>1017</td>
      <td>Sky is Clear</td>
      <td>1436874098</td>
      <td>2.10</td>
      <td>90.000</td>
      <td>Asti</td>
      <td>2015-07-14 13:41:38</td>
      <td>315</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>33.23</td>
      <td>45</td>
      <td>1016</td>
      <td>few clouds</td>
      <td>1436877645</td>
      <td>2.10</td>
      <td>120.000</td>
      <td>Asti</td>
      <td>2015-07-14 14:40:45</td>
      <td>315</td>
    </tr>
  </tbody>
</table>
</div>




```python
bologna1 = pd.read_csv('./bologna_150715.csv')
bologna2 = pd.read_csv('./bologna_250715.csv')
bologna3 = pd.read_csv('./bologna_270615.csv')
bologna = pd.concat([bologna1,bologna2,bologna3],ignore_index=True)
bologna.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>29.98</td>
      <td>57</td>
      <td>1021.0</td>
      <td>Sky is Clear</td>
      <td>1436863101</td>
      <td>0.51</td>
      <td>90.0</td>
      <td>Bologna</td>
      <td>2015-07-14 10:38:21</td>
      <td>71</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>30.26</td>
      <td>51</td>
      <td>1021.0</td>
      <td>moderate rain</td>
      <td>1436866691</td>
      <td>1.03</td>
      <td>157.0</td>
      <td>Bologna</td>
      <td>2015-07-14 11:38:11</td>
      <td>71</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>32.36</td>
      <td>46</td>
      <td>1021.0</td>
      <td>sky is clear</td>
      <td>1436870392</td>
      <td>2.06</td>
      <td>67.0</td>
      <td>Bologna</td>
      <td>2015-07-14 12:39:52</td>
      <td>71</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>31.16</td>
      <td>47</td>
      <td>1021.0</td>
      <td>moderate rain</td>
      <td>1436874000</td>
      <td>2.06</td>
      <td>90.0</td>
      <td>Bologna</td>
      <td>2015-07-14 13:40:00</td>
      <td>71</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>33.48</td>
      <td>44</td>
      <td>1021.0</td>
      <td>sky is clear</td>
      <td>1436877549</td>
      <td>2.06</td>
      <td>135.0</td>
      <td>Bologna</td>
      <td>2015-07-14 14:39:09</td>
      <td>71</td>
    </tr>
  </tbody>
</table>
</div>




```python
piacenza1 = pd.read_csv('./piacenza_150715.csv')
piacenza2 = pd.read_csv('./piacenza_250715.csv')
piacenza3 = pd.read_csv('./piacenza_270615.csv')
piacenza = pd.concat([piacenza1,piacenza2,piacenza3],ignore_index=True)
piacenza.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>27.99</td>
      <td>54</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436863096</td>
      <td>2.10</td>
      <td>100.0</td>
      <td>Piacenza</td>
      <td>2015-07-14 10:38:16</td>
      <td>200</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>29.13</td>
      <td>48</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436866685</td>
      <td>2.60</td>
      <td>0.0</td>
      <td>Piacenza</td>
      <td>2015-07-14 11:38:05</td>
      <td>200</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>30.21</td>
      <td>48</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436870387</td>
      <td>2.60</td>
      <td>140.0</td>
      <td>Piacenza</td>
      <td>2015-07-14 12:39:47</td>
      <td>200</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>31.40</td>
      <td>45</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436873990</td>
      <td>2.10</td>
      <td>0.0</td>
      <td>Piacenza</td>
      <td>2015-07-14 13:39:50</td>
      <td>200</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>31.88</td>
      <td>48</td>
      <td>1010</td>
      <td>Sky is Clear</td>
      <td>1436877535</td>
      <td>0.51</td>
      <td>23.0</td>
      <td>Piacenza</td>
      <td>2015-07-14 14:38:55</td>
      <td>200</td>
    </tr>
  </tbody>
</table>
</div>




```python
cesena1 = pd.read_csv('./cesena_150715.csv')
cesena2 = pd.read_csv('./cesena_250715.csv')
cesena3 = pd.read_csv('./cesena_270615.csv')
cesena = pd.concat([cesena1,cesena2,cesena3],ignore_index=True)
cesena.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>29.15</td>
      <td>83</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436863101</td>
      <td>3.62</td>
      <td>94.001</td>
      <td>Cesena</td>
      <td>2015-07-14 10:38:21</td>
      <td>14</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>29.37</td>
      <td>74</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436866691</td>
      <td>3.60</td>
      <td>20.000</td>
      <td>Cesena</td>
      <td>2015-07-14 11:38:11</td>
      <td>14</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>29.51</td>
      <td>78</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436870392</td>
      <td>3.60</td>
      <td>70.000</td>
      <td>Cesena</td>
      <td>2015-07-14 12:39:52</td>
      <td>14</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>29.88</td>
      <td>70</td>
      <td>1016</td>
      <td>moderate rain</td>
      <td>1436874000</td>
      <td>4.60</td>
      <td>60.000</td>
      <td>Cesena</td>
      <td>2015-07-14 13:40:00</td>
      <td>14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>30.12</td>
      <td>70</td>
      <td>1016</td>
      <td>moderate rain</td>
      <td>1436877549</td>
      <td>4.10</td>
      <td>70.000</td>
      <td>Cesena</td>
      <td>2015-07-14 14:39:09</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
faenza1 = pd.read_csv('./faenza_150715.csv')
faenza2 = pd.read_csv('./faenza_250715.csv')
faenza3 = pd.read_csv('./faenza_270615.csv')
faenza = pd.concat([faenza1,faenza2,faenza3],ignore_index=True)
faenza.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>29.40</td>
      <td>83</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436863177</td>
      <td>3.62</td>
      <td>94.001</td>
      <td>Faenza</td>
      <td>2015-07-14 10:39:37</td>
      <td>37</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>30.12</td>
      <td>78</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436866759</td>
      <td>3.10</td>
      <td>80.000</td>
      <td>Faenza</td>
      <td>2015-07-14 11:39:19</td>
      <td>37</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>30.10</td>
      <td>78</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436870510</td>
      <td>3.60</td>
      <td>70.000</td>
      <td>Faenza</td>
      <td>2015-07-14 12:41:50</td>
      <td>37</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>30.75</td>
      <td>74</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436874099</td>
      <td>4.60</td>
      <td>90.000</td>
      <td>Faenza</td>
      <td>2015-07-14 13:41:39</td>
      <td>37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>30.71</td>
      <td>66</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436877646</td>
      <td>5.10</td>
      <td>100.000</td>
      <td>Faenza</td>
      <td>2015-07-14 14:40:46</td>
      <td>37</td>
    </tr>
  </tbody>
</table>
</div>



查看列数

去除没用的列


```python
ferrara.drop('Unnamed: 0',axis=1,inplace=True)
torino.drop('Unnamed: 0',axis=1,inplace=True)
mantova.drop('Unnamed: 0',axis=1,inplace=True)
milano.drop('Unnamed: 0',axis=1,inplace=True)
ravenna.drop('Unnamed: 0',axis=1,inplace=True)
asti.drop('Unnamed: 0',axis=1,inplace=True)
bologna.drop('Unnamed: 0',axis=1,inplace=True)
piacenza.drop('Unnamed: 0',axis=1,inplace=True)
faenza.drop('Unnamed: 0',axis=1,inplace=True)
```

显示最高温度与离海远近的关系


```python
faenza.dist
```




    0     37
    1     37
    2     37
    3     37
    4     37
    5     37
    6     37
    7     37
    8     37
    9     37
    10    37
    11    37
    12    37
    13    37
    14    37
    15    37
    16    37
    17    37
    18    37
    19    37
    20    37
    21    37
    22    37
    23    37
    24    37
    25    37
    26    37
    27    37
    28    37
    29    37
          ..
    37    37
    38    37
    39    37
    40    37
    41    37
    42    37
    43    37
    44    37
    45    37
    46    37
    47    37
    48    37
    49    37
    50    37
    51    37
    52    37
    53    37
    54    37
    55    37
    56    37
    57    37
    58    37
    59    37
    60    37
    61    37
    62    37
    63    37
    64    37
    65    37
    66    37
    Name: dist, Length: 67, dtype: int64




```python
city_list = [ferrara,torino,mantova,milano,ravenna,asti,bologna,piacenza,faenza]
```


```python
dist = [city['dist'][0] for city in city_list]
dist
```




    [47, 357, 121, 250, 8, 315, 71, 200, 37]




```python
max_temp = [city['temp'].max() for city in city_list]
max_temp
```




    [33.43000000000001,
     34.69,
     34.18000000000001,
     34.81,
     32.79000000000002,
     34.31,
     33.850000000000016,
     33.920000000000016,
     32.74000000000001]




```python
x = np.array(dist)
y = np.array(max_temp)

plt.scatter(x,y)
```




    <matplotlib.collections.PathCollection at 0x24b9a4a99e8>




![png](output_22_1.png)


观察发现，离海近的可以形成一条直线，离海远的也能形成一条直线。

首先使用numpy：把列表转换为numpy数组，用于后续计算。

分别以100公里和50公里为分界点，划分为离海近和离海远的两组数据


```python
max_temp = np.array(max_temp)
```


```python
dist = np.array(dist)
```


```python
dist
```




    array([ 47, 357, 121, 250,   8, 315,  71, 200,  37], dtype=int64)




```python
far_city = dist>50
near_city = dist<100
```


```python
near_dist = dist[near_city]
near_temp = max_temp[near_city]

far_dist = dist[far_city]
far_temp = max_temp[far_city]
```


```python
display(near_dist,near_temp)
display(far_dist,far_temp)
```


    array([47,  8, 71, 37], dtype=int64)



    array([33.43, 32.79, 33.85, 32.74])



    array([357, 121, 250, 315,  71, 200], dtype=int64)



    array([34.69, 34.18, 34.81, 34.31, 33.85, 33.92])



```python

plt.scatter(far_dist,far_temp,color='red')
plt.scatter(near_dist,near_temp,color='green')
```




    <matplotlib.collections.PathCollection at 0x24b9a5460f0>




![png](output_30_1.png)


使用支持向量机计算回归参数


```python
# 机器学习 线性回归模型
# scikit-learn
from sklearn.linear_model import LinearRegression
```

查看最低温度与海洋距离的关系


```python
# 相当于假设一种函数关系 
# f(x) = wx+b
# x**2 + y**2 = R
linear = LinearRegression()
# 优化算法，找到最优解（误差最小的函数表达）
```


```python
# 训练模型
# 距离可以认为是自变量 
# 温度认为是因变量
```


```python
# 一个被训练过的模型，就是一个预测函数表达式f(x) = wx+b
linear.fit(near_dist.reshape(-1,1),near_temp)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)




```python
# 预测  利用估计函数进行求解
linear.predict([[71],[32],[35],[56]])
```




    array([33.73987015, 33.04706235, 33.10035526, 33.47340561])




```python
xmin,xmax = near_dist.min(),near_dist.max()+10
x = np.linspace(xmin,xmax,100).reshape(-1,1)
x
```




    array([[ 8.        ],
           [ 8.73737374],
           [ 9.47474747],
           [10.21212121],
           [10.94949495],
           [11.68686869],
           [12.42424242],
           [13.16161616],
           [13.8989899 ],
           [14.63636364],
           [15.37373737],
           [16.11111111],
           [16.84848485],
           [17.58585859],
           [18.32323232],
           [19.06060606],
           [19.7979798 ],
           [20.53535354],
           [21.27272727],
           [22.01010101],
           [22.74747475],
           [23.48484848],
           [24.22222222],
           [24.95959596],
           [25.6969697 ],
           [26.43434343],
           [27.17171717],
           [27.90909091],
           [28.64646465],
           [29.38383838],
           [30.12121212],
           [30.85858586],
           [31.5959596 ],
           [32.33333333],
           [33.07070707],
           [33.80808081],
           [34.54545455],
           [35.28282828],
           [36.02020202],
           [36.75757576],
           [37.49494949],
           [38.23232323],
           [38.96969697],
           [39.70707071],
           [40.44444444],
           [41.18181818],
           [41.91919192],
           [42.65656566],
           [43.39393939],
           [44.13131313],
           [44.86868687],
           [45.60606061],
           [46.34343434],
           [47.08080808],
           [47.81818182],
           [48.55555556],
           [49.29292929],
           [50.03030303],
           [50.76767677],
           [51.50505051],
           [52.24242424],
           [52.97979798],
           [53.71717172],
           [54.45454545],
           [55.19191919],
           [55.92929293],
           [56.66666667],
           [57.4040404 ],
           [58.14141414],
           [58.87878788],
           [59.61616162],
           [60.35353535],
           [61.09090909],
           [61.82828283],
           [62.56565657],
           [63.3030303 ],
           [64.04040404],
           [64.77777778],
           [65.51515152],
           [66.25252525],
           [66.98989899],
           [67.72727273],
           [68.46464646],
           [69.2020202 ],
           [69.93939394],
           [70.67676768],
           [71.41414141],
           [72.15151515],
           [72.88888889],
           [73.62626263],
           [74.36363636],
           [75.1010101 ],
           [75.83838384],
           [76.57575758],
           [77.31313131],
           [78.05050505],
           [78.78787879],
           [79.52525253],
           [80.26262626],
           [81.        ]])




```python
y_ = linear.predict(x)
```


```python
plt.plot(x,y_)
plt.scatter(far_dist,far_temp,color='red')
plt.scatter(near_dist,near_temp,color='green')
```




    <matplotlib.collections.PathCollection at 0x24b9c393b70>




![png](output_40_1.png)



```python
linear1 = LinearRegression()
linear1.fit(far_dist.reshape(-1,1),far_temp)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)




```python
xmin1,xmax1 = far_dist.min()-10,far_dist.max()
x1 = np.linspace(xmin1,xmax1,100).reshape(-1,1)
y1_ = linear1.predict(x1)
```


```python

plt.scatter(far_dist,far_temp,color='red')
plt.scatter(near_dist,near_temp,color='green')
plt.plot(x,y_,label='near city predict')
plt.plot(x1,y1_,label='far city predict')
plt.legend()

plt.xlabel('distance')
plt.ylabel('temperature')
```




    Text(0,0.5,'temperature')




![png](output_43_1.png)


最低湿度与海洋距离的关系


```python
min_humiditys = [city['humidity'].min() for city in city_list]
plt.figure(figsize=(6,2))
plt.scatter(dist,min_humiditys)
plt.xlabel('distance')
plt.ylabel('min_humidity')
```




    Text(0,0.5,'min_humidity')




![png](output_45_1.png)


最高湿度与海洋距离的关系


```python
min_humiditys = [city['humidity'].max() for city in city_list]
plt.figure(figsize=(6,2))
plt.scatter(dist,min_humiditys)
plt.xlabel('distance')
plt.ylabel('max_humidity')
```




    Text(0,0.5,'max_humidity')




![png](output_47_1.png)


平均湿度与海洋距离的关系


```python
mean_humiditys = [city['humidity'].mean() for city in city_list]
plt.figure(figsize=(6,2))
plt.scatter(dist,min_humiditys)
plt.xlabel('distance')
plt.ylabel('mean_humidity')
```




    Text(0,0.5,'mean_humidity')




![png](output_49_1.png)


思考：模仿最高温度，得到平均湿度与海洋距离的回归曲线


```python
# 确定了一个线性回归模型
linear2 = LinearRegression()
```


```python
# 寻找因变量和自变量
far_city
near_city
```




    array([ True, False, False, False,  True, False,  True, False,  True])




```python
mean_humiditys = np.array(mean_humiditys)
```


```python
far_humidity,near_humidity = mean_humiditys[far_city],mean_humiditys[near_city]

display(far_humidity,near_humidity)
display(far_dist,near_dist)
```


    array([63.19117647, 59.14705882, 56.98484848, 63.13235294, 61.33823529,
           59.30882353])



    array([61.30882353, 68.01515152, 61.33823529, 81.07462687])



    array([357, 121, 250, 315,  71, 200], dtype=int64)



    array([47,  8, 71, 37], dtype=int64)



```python
linear2.fit(near_dist.reshape(-1,1),near_humidity.reshape(-1,1))
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)




```python
xmin,xmax = near_dist.min(),near_dist.max()+10
x = np.linspace(xmin,xmax,100).reshape(-1,1)
y_ = linear2.predict(x)
```


```python
linear3 = LinearRegression()
linear3.fit(far_dist.reshape(-1,1),far_humidity)
xmin1,xmax1 = far_dist.min()-10,far_dist.max()
x1 = np.linspace(xmin1,xmax1,100).reshape(-1,1)
y1_ = linear3.predict(x1)
```


```python
mean_humiditys = [city['humidity'].mean() for city in city_list]
plt.figure(figsize=(6,2))
plt.scatter(dist,min_humiditys)
plt.xlabel('distance')
plt.ylabel('mean_humidity')
plt.plot(x,y_,label='near_humidity_predict')
plt.plot(x1,y1_,label='far_humidity_predict')
plt.legend()
```




    <matplotlib.legend.Legend at 0x24b9c5c6978>




![png](output_58_1.png)


风向与风速的关系


```python
faenza.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>29.4</td>
      <td>83</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436863177</td>
      <td>3.62</td>
      <td>94.001</td>
      <td>Faenza</td>
      <td>2015-07-14 10:39:37</td>
      <td>37</td>
    </tr>
  </tbody>
</table>
</div>




```python
wind_speeds = [city['wind_speed'] for city in city_list]
wind_degs = [city['wind_deg'] for city in city_list]
city_humidity = [city['humidity'] for city in city_list]
```

在子图中，同时比较风向与湿度和风力的关系


```python
plt.figure(figsize=(10,6))
axes1 = plt.subplot(211)
axes1.scatter(wind_degs[0],city_humidity[0],color='orange')
axes1.set_title('wind_deg & humidity')

axes2 = plt.subplot(212)
axes2.scatter(wind_degs[0],wind_speeds[0],color='blue')
axes2.set_title('wind_deg & wind_speed')
```




    Text(0.5,1,'wind_deg & wind_speed')




![png](output_63_1.png)


由于风向是360度，我们可以考虑使用玫瑰图（极坐标条形图）


```python
wind_degs
```




    [0     180.00000
     1     135.00000
     2     113.00000
     3      90.00000
     4      68.00000
     5     113.00000
     6     113.00000
     7     180.00000
     8      90.00000
     9     135.00000
     10    113.00000
     11    135.00000
     12     90.00000
     13     68.00000
     14    135.00000
     15    104.50100
     16    104.50100
     17     48.00330
     18     48.00330
     19    185.50300
     20     79.50130
     21    238.00100
     22     79.50130
     23     69.50090
     24     23.00000
     25     45.00000
     26    123.00300
     27    123.00300
     28     23.00000
     29    135.00000
             ...    
     38    225.00000
     39    198.00200
     40    248.00000
     41     31.50360
     42     31.50360
     43    225.00000
     44    225.00000
     45    270.00000
     46    248.00000
     47    293.00000
     48    135.00000
     49     45.00000
     50    158.00000
     51     14.50020
     52    203.00000
     53    203.00000
     54     45.00000
     55    135.00000
     56     90.00000
     57    113.00000
     58    203.00000
     59     23.00000
     60    126.51500
     61     23.00000
     62     23.00000
     63     23.00000
     64    248.00300
     65    248.00300
     66      5.50055
     67      5.50055
     Name: wind_deg, Length: 68, dtype: float64, 0      20
     1      80
     2     100
     3      90
     4     120
     5     110
     6     100
     7     100
     8     100
     9     240
     10     70
     11     40
     12     30
     13    330
     14    340
     15    350
     16    340
     17    360
     18    310
     19      0
     20    350
     21    330
     22      0
     23     50
     24     70
     25     70
     26     70
     27     10
     28    120
     29      0
          ... 
     38     10
     39    280
     40    290
     41      0
     42    350
     43    330
     44     50
     45      0
     46      0
     47      0
     48      0
     49     80
     50     50
     51     50
     52     70
     53     60
     54    360
     55    170
     56      0
     57     90
     58     50
     59     10
     60    340
     61    340
     62    340
     63    340
     64     30
     65    360
     66     10
     67     40
     Name: wind_deg, Length: 68, dtype: int64, 0     140
     1       0
     2     170
     3       0
     4     180
     5     150
     6     140
     7       0
     8     150
     9     160
     10    160
     11    100
     12     90
     13     70
     14     70
     15     60
     16     80
     17     40
     18    330
     19    330
     20    330
     21      0
     22    120
     23    110
     24      0
     25    130
     26    130
     27    120
     28    130
     29    130
          ... 
     38    250
     39    260
     40    320
     41    330
     42      0
     43    310
     44    330
     45    250
     46    280
     47    280
     48     70
     49    110
     50    170
     51    210
     52    180
     53    150
     54    210
     55    290
     56    230
     57    200
     58    210
     59     70
     60     90
     61    100
     62     20
     63     10
     64    350
     65    350
     66    320
     67    170
     Name: wind_deg, Length: 68, dtype: int64, 0     100
     1       0
     2     140
     3       0
     4      80
     5       0
     6     230
     7     220
     8     210
     9     210
     10    220
     11    200
     12    200
     13      0
     14      0
     15     70
     16     80
     17     80
     18      0
     19     90
     20    140
     21      0
     22     60
     23    100
     24     90
     25     70
     26     80
     27    130
     28    130
     29      0
          ... 
     36    140
     37     30
     38    350
     39     10
     40      0
     41    110
     42     10
     43      0
     44    200
     45      0
     46      0
     47     70
     48    140
     49    160
     50    210
     51    220
     52    210
     53    230
     54    250
     55    220
     56    270
     57    310
     58    200
     59    210
     60    120
     61     90
     62     50
     63     40
     64     40
     65      0
     Name: wind_deg, Length: 66, dtype: int64, 0      10.0000
     1      20.0000
     2      40.0000
     3      90.0000
     4      87.0000
     5      79.0000
     6      70.0000
     7      80.0000
     8      90.0000
     9      90.0000
     10    105.0000
     11    100.0000
     12    110.0000
     13    116.5040
     14    145.0010
     15    145.0010
     16    145.0010
     17    155.5030
     18    155.5030
     19    155.5030
     20    190.0000
     21    126.5010
     22    250.0000
     23     99.0009
     24    330.0030
     25     20.0000
     26     70.0000
     27     70.0000
     28     10.0000
     29     80.0000
             ...   
     36    190.0000
     37    180.0000
     38    193.5020
     39    193.5020
     40    224.0040
     41    224.0040
     42    224.0040
     43    180.0000
     44    190.0000
     45    254.0010
     46    257.5030
     47    190.0000
     48    159.5000
     49    100.0000
     50     80.0000
     51     90.0000
     52     80.0000
     53     80.0000
     54     90.0000
     55     90.0000
     56     90.0000
     57     97.0000
     58     89.0000
     59     88.0147
     60    107.0040
     61    107.0040
     62    132.5030
     63    132.5030
     64    132.5030
     65    251.0000
     Name: wind_deg, Length: 66, dtype: float64, 0      42.501
     1     263.000
     2     100.000
     3      90.000
     4     120.000
     5     110.000
     6     100.000
     7     100.000
     8     100.000
     9     240.000
     10     70.000
     11     40.000
     12     30.000
     13    330.000
     14      0.000
     15    350.000
     16    340.000
     17    360.000
     18    310.000
     19      0.000
     20    350.000
     21    330.000
     22      0.000
     23     50.000
     24     70.000
     25     70.000
     26     24.000
     27     10.000
     28    120.000
     29      0.000
            ...   
     38     10.000
     39    280.000
     40    290.000
     41      0.000
     42    350.000
     43    330.000
     44      0.000
     45      0.000
     46      0.000
     47      0.000
     48     80.000
     49     50.000
     50    100.000
     51     70.000
     52    154.505
     53     50.000
     54      0.000
     55    140.000
     56     50.000
     57    100.000
     58     10.000
     59    340.000
     60    320.000
     61    340.000
     62    360.000
     63     30.000
     64    360.000
     65    321.501
     66      0.000
     67      0.000
     Name: wind_deg, Length: 68, dtype: float64, 0      90.00000
     1     157.00000
     2      67.00000
     3      90.00000
     4     135.00000
     5      22.00000
     6     337.00000
     7       0.00000
     8     112.00000
     9      90.00000
     10    112.00000
     11    128.00000
     12     91.00400
     13     91.00400
     14    120.00000
     15    163.00100
     16    129.00000
     17    185.50300
     18    185.50300
     19    185.50300
     20    238.00100
     21    238.00100
     22    238.00100
     23     69.50090
     24    315.00000
     25     69.00000
     26     28.00000
     27     74.00000
     28    201.00000
     29    225.00000
             ...    
     38    171.00000
     39    171.00000
     40    171.00000
     41    171.00000
     42    171.00000
     43    171.00000
     44    171.00000
     45    171.00000
     46    171.00000
     47    171.00000
     48    225.00000
     49    256.00000
     50    325.00000
     51     22.00000
     52     28.00000
     53    291.00000
     54    282.00000
     55    188.00000
     56    197.00000
     57    205.00000
     58    102.00000
     59     75.00000
     60     71.00000
     61      4.00000
     62    216.00000
     63    248.00300
     64    207.00000
     65      5.50055
     66    211.00000
     67      5.50055
     Name: wind_deg, Length: 68, dtype: float64, 0     100.000
     1       0.000
     2     140.000
     3       0.000
     4      23.000
     5       0.000
     6     230.000
     7     104.001
     8     210.000
     9     210.000
     10    220.000
     11    200.000
     12    313.504
     13      0.000
     14      0.000
     15     70.000
     16     80.000
     17     80.000
     18      0.000
     19     90.000
     20    140.000
     21      0.000
     22    330.501
     23    100.000
     24     90.000
     25     55.000
     26     80.000
     27    130.000
     28    130.000
     29      0.000
            ...   
     38    350.000
     39     30.000
     40     10.000
     41     20.000
     42     10.000
     43    240.000
     44    200.000
     45      0.000
     46      0.000
     47    340.000
     48    279.000
     49    140.000
     50    160.000
     51      0.000
     52    230.000
     53    305.000
     54    316.000
     55    347.000
     56    280.000
     57    283.000
     58    311.000
     59     36.000
     60     58.000
     61     41.000
     62     59.000
     63      3.000
     64     48.000
     65    226.003
     66    178.000
     67    138.501
     Name: wind_deg, Length: 68, dtype: float64, 0      94.0010
     1      80.0000
     2      70.0000
     3      90.0000
     4     100.0000
     5      90.0000
     6     100.0000
     7     120.0000
     8     110.0000
     9     120.0000
     10    120.0000
     11    110.0000
     12    110.0000
     13    116.5040
     14    163.0010
     15    240.0000
     16    250.0000
     17    250.0000
     18    155.5030
     19    155.5030
     20    126.5010
     21    126.5010
     22    250.0000
     23     99.0009
     24    310.0000
     25     40.0000
     26     70.0000
     27     70.0000
     28     60.0000
     29     80.0000
             ...   
     37    250.0000
     38    170.0000
     39    250.0000
     40    210.5040
     41    224.0040
     42    230.0000
     43    230.0000
     44    254.0010
     45    254.0010
     46    250.0000
     47    260.0000
     48     14.5002
     49    100.0000
     50    120.0000
     51    110.0000
     52    110.0000
     53    110.0000
     54    110.0000
     55    120.0000
     56    120.0000
     57    120.0000
     58     90.0000
     59     90.0000
     60    210.0000
     61    218.5040
     62    330.0000
     63    320.0000
     64    300.0000
     65    270.0000
     66    260.0000
     Name: wind_deg, Length: 67, dtype: float64]




```python
# 如何根据风向分组 假设我们要分8组
```


```python
s = Series(np.array([1,3,5,7,9,4,2,5,7,6]))
s.plot(kind='hist',bins=8)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24b9b263470>




![png](output_67_1.png)



```python
faenza
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>temp</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>description</th>
      <th>dt</th>
      <th>wind_speed</th>
      <th>wind_deg</th>
      <th>city</th>
      <th>day</th>
      <th>dist</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>29.40</td>
      <td>83</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436863177</td>
      <td>3.62</td>
      <td>94.0010</td>
      <td>Faenza</td>
      <td>2015-07-14 10:39:37</td>
      <td>37</td>
    </tr>
    <tr>
      <th>1</th>
      <td>30.12</td>
      <td>78</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436866759</td>
      <td>3.10</td>
      <td>80.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 11:39:19</td>
      <td>37</td>
    </tr>
    <tr>
      <th>2</th>
      <td>30.10</td>
      <td>78</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436870510</td>
      <td>3.60</td>
      <td>70.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 12:41:50</td>
      <td>37</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30.75</td>
      <td>74</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436874099</td>
      <td>4.60</td>
      <td>90.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 13:41:39</td>
      <td>37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>30.71</td>
      <td>66</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436877646</td>
      <td>5.10</td>
      <td>100.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 14:40:46</td>
      <td>37</td>
    </tr>
    <tr>
      <th>5</th>
      <td>31.29</td>
      <td>66</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436881330</td>
      <td>5.70</td>
      <td>90.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 15:42:10</td>
      <td>37</td>
    </tr>
    <tr>
      <th>6</th>
      <td>31.29</td>
      <td>66</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436884929</td>
      <td>5.70</td>
      <td>100.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 16:42:09</td>
      <td>37</td>
    </tr>
    <tr>
      <th>7</th>
      <td>30.40</td>
      <td>66</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436888513</td>
      <td>5.70</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 17:41:53</td>
      <td>37</td>
    </tr>
    <tr>
      <th>8</th>
      <td>30.67</td>
      <td>62</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436892134</td>
      <td>5.70</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 18:42:14</td>
      <td>37</td>
    </tr>
    <tr>
      <th>9</th>
      <td>29.68</td>
      <td>65</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436895723</td>
      <td>4.60</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 19:42:03</td>
      <td>37</td>
    </tr>
    <tr>
      <th>10</th>
      <td>28.07</td>
      <td>74</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436899337</td>
      <td>4.10</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 20:42:17</td>
      <td>37</td>
    </tr>
    <tr>
      <th>11</th>
      <td>27.10</td>
      <td>83</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436902943</td>
      <td>2.60</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 21:42:23</td>
      <td>37</td>
    </tr>
    <tr>
      <th>12</th>
      <td>26.19</td>
      <td>94</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436906533</td>
      <td>2.10</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-07-14 22:42:13</td>
      <td>37</td>
    </tr>
    <tr>
      <th>13</th>
      <td>25.51</td>
      <td>94</td>
      <td>1014</td>
      <td>moderate rain</td>
      <td>1436910150</td>
      <td>2.41</td>
      <td>116.5040</td>
      <td>Faenza</td>
      <td>2015-07-14 23:42:30</td>
      <td>37</td>
    </tr>
    <tr>
      <th>14</th>
      <td>24.90</td>
      <td>94</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436913739</td>
      <td>1.21</td>
      <td>163.0010</td>
      <td>Faenza</td>
      <td>2015-07-15 00:42:19</td>
      <td>37</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24.46</td>
      <td>94</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436917313</td>
      <td>1.00</td>
      <td>240.0000</td>
      <td>Faenza</td>
      <td>2015-07-15 01:41:53</td>
      <td>37</td>
    </tr>
    <tr>
      <th>16</th>
      <td>24.19</td>
      <td>88</td>
      <td>1015</td>
      <td>moderate rain</td>
      <td>1436920932</td>
      <td>1.50</td>
      <td>250.0000</td>
      <td>Faenza</td>
      <td>2015-07-15 02:42:12</td>
      <td>37</td>
    </tr>
    <tr>
      <th>17</th>
      <td>23.99</td>
      <td>94</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436924427</td>
      <td>0.50</td>
      <td>250.0000</td>
      <td>Faenza</td>
      <td>2015-07-15 03:40:27</td>
      <td>37</td>
    </tr>
    <tr>
      <th>18</th>
      <td>23.00</td>
      <td>88</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436928078</td>
      <td>1.12</td>
      <td>155.5030</td>
      <td>Faenza</td>
      <td>2015-07-15 04:41:18</td>
      <td>37</td>
    </tr>
    <tr>
      <th>19</th>
      <td>23.00</td>
      <td>88</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436931718</td>
      <td>1.12</td>
      <td>155.5030</td>
      <td>Faenza</td>
      <td>2015-07-15 05:41:58</td>
      <td>37</td>
    </tr>
    <tr>
      <th>20</th>
      <td>22.51</td>
      <td>88</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436935299</td>
      <td>1.52</td>
      <td>126.5010</td>
      <td>Faenza</td>
      <td>2015-07-15 06:41:39</td>
      <td>37</td>
    </tr>
    <tr>
      <th>21</th>
      <td>23.01</td>
      <td>94</td>
      <td>1015</td>
      <td>Sky is Clear</td>
      <td>1436938883</td>
      <td>1.52</td>
      <td>126.5010</td>
      <td>Faenza</td>
      <td>2015-07-15 07:41:23</td>
      <td>37</td>
    </tr>
    <tr>
      <th>22</th>
      <td>25.00</td>
      <td>88</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436942516</td>
      <td>1.00</td>
      <td>250.0000</td>
      <td>Faenza</td>
      <td>2015-07-15 08:41:56</td>
      <td>37</td>
    </tr>
    <tr>
      <th>23</th>
      <td>27.51</td>
      <td>88</td>
      <td>1016</td>
      <td>Sky is Clear</td>
      <td>1436945951</td>
      <td>2.57</td>
      <td>99.0009</td>
      <td>Faenza</td>
      <td>2015-07-15 09:39:11</td>
      <td>37</td>
    </tr>
    <tr>
      <th>24</th>
      <td>32.08</td>
      <td>79</td>
      <td>1010</td>
      <td>moderate rain</td>
      <td>1437730850</td>
      <td>1.50</td>
      <td>310.0000</td>
      <td>Faenza</td>
      <td>2015-07-24 11:40:50</td>
      <td>37</td>
    </tr>
    <tr>
      <th>25</th>
      <td>32.40</td>
      <td>75</td>
      <td>1009</td>
      <td>moderate rain</td>
      <td>1437734493</td>
      <td>3.60</td>
      <td>40.0000</td>
      <td>Faenza</td>
      <td>2015-07-24 12:41:33</td>
      <td>37</td>
    </tr>
    <tr>
      <th>26</th>
      <td>32.74</td>
      <td>75</td>
      <td>1009</td>
      <td>moderate rain</td>
      <td>1437738046</td>
      <td>3.60</td>
      <td>70.0000</td>
      <td>Faenza</td>
      <td>2015-07-24 13:40:46</td>
      <td>37</td>
    </tr>
    <tr>
      <th>27</th>
      <td>32.70</td>
      <td>79</td>
      <td>1009</td>
      <td>moderate rain</td>
      <td>1437741579</td>
      <td>5.10</td>
      <td>70.0000</td>
      <td>Faenza</td>
      <td>2015-07-24 14:39:39</td>
      <td>37</td>
    </tr>
    <tr>
      <th>28</th>
      <td>32.33</td>
      <td>70</td>
      <td>1008</td>
      <td>moderate rain</td>
      <td>1437745188</td>
      <td>3.60</td>
      <td>60.0000</td>
      <td>Faenza</td>
      <td>2015-07-24 15:39:48</td>
      <td>37</td>
    </tr>
    <tr>
      <th>29</th>
      <td>32.40</td>
      <td>74</td>
      <td>1008</td>
      <td>moderate rain</td>
      <td>1437748777</td>
      <td>2.60</td>
      <td>80.0000</td>
      <td>Faenza</td>
      <td>2015-07-24 16:39:37</td>
      <td>37</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>37</th>
      <td>27.22</td>
      <td>100</td>
      <td>1008</td>
      <td>moderate rain</td>
      <td>1437777556</td>
      <td>1.50</td>
      <td>250.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 00:39:16</td>
      <td>37</td>
    </tr>
    <tr>
      <th>38</th>
      <td>26.54</td>
      <td>100</td>
      <td>1007</td>
      <td>moderate rain</td>
      <td>1437781277</td>
      <td>0.50</td>
      <td>170.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 01:41:17</td>
      <td>37</td>
    </tr>
    <tr>
      <th>39</th>
      <td>25.93</td>
      <td>100</td>
      <td>1007</td>
      <td>moderate rain</td>
      <td>1437784850</td>
      <td>1.00</td>
      <td>250.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 02:40:50</td>
      <td>37</td>
    </tr>
    <tr>
      <th>40</th>
      <td>25.53</td>
      <td>100</td>
      <td>1007</td>
      <td>moderate rain</td>
      <td>1437788407</td>
      <td>2.37</td>
      <td>210.5040</td>
      <td>Faenza</td>
      <td>2015-07-25 03:40:07</td>
      <td>37</td>
    </tr>
    <tr>
      <th>41</th>
      <td>25.01</td>
      <td>94</td>
      <td>1007</td>
      <td>moderate rain</td>
      <td>1437792027</td>
      <td>3.32</td>
      <td>224.0040</td>
      <td>Faenza</td>
      <td>2015-07-25 04:40:27</td>
      <td>37</td>
    </tr>
    <tr>
      <th>42</th>
      <td>24.03</td>
      <td>94</td>
      <td>1007</td>
      <td>moderate rain</td>
      <td>1437795653</td>
      <td>1.00</td>
      <td>230.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 05:40:53</td>
      <td>37</td>
    </tr>
    <tr>
      <th>43</th>
      <td>24.77</td>
      <td>94</td>
      <td>1007</td>
      <td>moderate rain</td>
      <td>1437799262</td>
      <td>1.00</td>
      <td>230.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 06:41:02</td>
      <td>37</td>
    </tr>
    <tr>
      <th>44</th>
      <td>25.59</td>
      <td>94</td>
      <td>1008</td>
      <td>Sky is Clear</td>
      <td>1437802784</td>
      <td>2.61</td>
      <td>254.0010</td>
      <td>Faenza</td>
      <td>2015-07-25 07:39:44</td>
      <td>37</td>
    </tr>
    <tr>
      <th>45</th>
      <td>27.23</td>
      <td>83</td>
      <td>1008</td>
      <td>Sky is Clear</td>
      <td>1437806426</td>
      <td>2.61</td>
      <td>254.0010</td>
      <td>Faenza</td>
      <td>2015-07-25 08:40:26</td>
      <td>37</td>
    </tr>
    <tr>
      <th>46</th>
      <td>30.20</td>
      <td>70</td>
      <td>1008</td>
      <td>Sky is Clear</td>
      <td>1437809988</td>
      <td>2.10</td>
      <td>250.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 09:39:48</td>
      <td>37</td>
    </tr>
    <tr>
      <th>47</th>
      <td>31.12</td>
      <td>70</td>
      <td>1008</td>
      <td>moderate rain</td>
      <td>1437813634</td>
      <td>3.60</td>
      <td>260.0000</td>
      <td>Faenza</td>
      <td>2015-07-25 10:40:34</td>
      <td>37</td>
    </tr>
    <tr>
      <th>48</th>
      <td>25.44</td>
      <td>69</td>
      <td>1018</td>
      <td>very heavy rain</td>
      <td>1435390925</td>
      <td>1.29</td>
      <td>14.5002</td>
      <td>Faenza</td>
      <td>2015-06-27 09:42:05</td>
      <td>37</td>
    </tr>
    <tr>
      <th>49</th>
      <td>26.38</td>
      <td>73</td>
      <td>1017</td>
      <td>very heavy rain</td>
      <td>1435394243</td>
      <td>2.10</td>
      <td>100.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 10:37:23</td>
      <td>37</td>
    </tr>
    <tr>
      <th>50</th>
      <td>27.70</td>
      <td>69</td>
      <td>1017</td>
      <td>very heavy rain</td>
      <td>1435399019</td>
      <td>3.10</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 11:56:59</td>
      <td>37</td>
    </tr>
    <tr>
      <th>51</th>
      <td>29.04</td>
      <td>61</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435402422</td>
      <td>3.10</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 12:53:42</td>
      <td>37</td>
    </tr>
    <tr>
      <th>52</th>
      <td>29.11</td>
      <td>69</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435406058</td>
      <td>3.60</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 13:54:18</td>
      <td>37</td>
    </tr>
    <tr>
      <th>53</th>
      <td>29.33</td>
      <td>65</td>
      <td>1015</td>
      <td>very heavy rain</td>
      <td>1435409704</td>
      <td>5.70</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 14:55:04</td>
      <td>37</td>
    </tr>
    <tr>
      <th>54</th>
      <td>29.20</td>
      <td>65</td>
      <td>1014</td>
      <td>very heavy rain</td>
      <td>1435416898</td>
      <td>5.10</td>
      <td>110.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 16:54:58</td>
      <td>37</td>
    </tr>
    <tr>
      <th>55</th>
      <td>28.88</td>
      <td>65</td>
      <td>1014</td>
      <td>very heavy rain</td>
      <td>1435420542</td>
      <td>6.20</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 17:55:42</td>
      <td>37</td>
    </tr>
    <tr>
      <th>56</th>
      <td>27.53</td>
      <td>65</td>
      <td>1014</td>
      <td>very heavy rain</td>
      <td>1435424296</td>
      <td>6.70</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 18:58:16</td>
      <td>37</td>
    </tr>
    <tr>
      <th>57</th>
      <td>26.12</td>
      <td>73</td>
      <td>1013</td>
      <td>very heavy rain</td>
      <td>1435427936</td>
      <td>6.20</td>
      <td>120.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 19:58:56</td>
      <td>37</td>
    </tr>
    <tr>
      <th>58</th>
      <td>22.32</td>
      <td>94</td>
      <td>1015</td>
      <td>very heavy rain</td>
      <td>1435438357</td>
      <td>2.60</td>
      <td>90.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 22:52:37</td>
      <td>37</td>
    </tr>
    <tr>
      <th>59</th>
      <td>21.38</td>
      <td>83</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435442241</td>
      <td>5.70</td>
      <td>90.0000</td>
      <td>Faenza</td>
      <td>2015-06-27 23:57:21</td>
      <td>37</td>
    </tr>
    <tr>
      <th>60</th>
      <td>21.16</td>
      <td>83</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435445863</td>
      <td>2.10</td>
      <td>210.0000</td>
      <td>Faenza</td>
      <td>2015-06-28 00:57:43</td>
      <td>37</td>
    </tr>
    <tr>
      <th>61</th>
      <td>20.00</td>
      <td>94</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435453232</td>
      <td>1.39</td>
      <td>218.5040</td>
      <td>Faenza</td>
      <td>2015-06-28 03:00:32</td>
      <td>37</td>
    </tr>
    <tr>
      <th>62</th>
      <td>19.48</td>
      <td>93</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435456487</td>
      <td>2.10</td>
      <td>330.0000</td>
      <td>Faenza</td>
      <td>2015-06-28 03:54:47</td>
      <td>37</td>
    </tr>
    <tr>
      <th>63</th>
      <td>19.16</td>
      <td>93</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435460042</td>
      <td>1.50</td>
      <td>320.0000</td>
      <td>Faenza</td>
      <td>2015-06-28 04:54:02</td>
      <td>37</td>
    </tr>
    <tr>
      <th>64</th>
      <td>18.62</td>
      <td>93</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435463880</td>
      <td>0.50</td>
      <td>300.0000</td>
      <td>Faenza</td>
      <td>2015-06-28 05:58:00</td>
      <td>37</td>
    </tr>
    <tr>
      <th>65</th>
      <td>19.34</td>
      <td>88</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435467179</td>
      <td>0.50</td>
      <td>270.0000</td>
      <td>Faenza</td>
      <td>2015-06-28 06:52:59</td>
      <td>37</td>
    </tr>
    <tr>
      <th>66</th>
      <td>21.05</td>
      <td>88</td>
      <td>1016</td>
      <td>very heavy rain</td>
      <td>1435470851</td>
      <td>2.10</td>
      <td>260.0000</td>
      <td>Faenza</td>
      <td>2015-06-28 07:54:11</td>
      <td>37</td>
    </tr>
  </tbody>
</table>
<p>67 rows × 10 columns</p>
</div>




```python
def draw_rose(city,feature1,feature2):
    bins = np.array([0,45,90,135,180,225,270,315])
    faenza_speeds = []
    for deg in bins:
        speed = city[feature1][(city[feature2] < deg+45) & (city[feature2] >= deg)].mean()
        faenza_speeds.append(speed)
    height = faenza_speeds
    index = np.array([0,45,90,135,180,225,270,315])
    index = index*np.pi/180
    plt.axes(polar=True)
    color = np.random.random(size=(8,3))
    plt.bar(x=index,height=height,color=color,align='edge')
    t = feature1 + '-' + feature2 + ' of ' + city['city'][0]
    plt.title(t)
```


```python
draw_rose(faenza,'wind_speed','wind_deg')
```


![png](output_70_0.png)


首先自定义一个画图函数

用numpy创建一个直方图，将360度划分为8个面元，将数据分类到这8个面元中

计算米兰各个方向上的风速


```python
draw_rose(milano,'wind_speed','wind_deg')
```


![png](output_74_0.png)



```python
draw_rose(faenza,'humidity','wind_deg')
```


![png](output_75_0.png)


将各个方向的风速保存在列表中

画出各个方向的风速

将上面步骤写成函数

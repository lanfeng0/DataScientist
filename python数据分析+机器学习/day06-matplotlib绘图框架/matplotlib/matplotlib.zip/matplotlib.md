
# matplotlib

## 目录
+ 一、【重点】Matplotlib基础知识

+ 二、设置plot的风格和样式
    + 1、【重点】点和线的样式
    + 2、X、Y轴坐标刻度


+ 三、2D图形
    + 1、示例
    + 2、【重点】直方图
    + 3、【重点】条形图
    + 4、【重点】饼图
    + 5、【重点】散点图
    
=============以上为重点=================

#### 下面的预习
+ 四、图形内的文字、注释、箭头
    + 1、图形内的文字
    + 2、注释
    + 3、箭头
    
+ 五、3D图
    + 1、曲面图

+ 六、玫瑰图

## 一、Matplotlib基础知识


```python
import matplotlib.pyplot as plt
%matplotlib inline
```

Matplotlib中的基本图表包括的元素
+ x轴和y轴  axis
水平和垂直的轴线


+ 轴标签 axisLabel
水平和垂直的轴标签


+ x轴和y轴刻度  tick
刻度标示坐标轴的分隔，包括最小刻度和最大刻度


+ x轴和y轴刻度标签  tick label
表示特定坐标轴的值


+ 绘图区域（坐标系）  axes
实际绘图的区域


+ 画布 figure
呈现所有的坐标系

![](matplotlib图像组成.PNG)

### 只含单一曲线的图


```python
import numpy as np
import pandas as pd
from pandas import Series,DataFrame
```


```python
# 绘制线性图就是plot函数
# 1. x轴跟y轴应该满足映射关系（数量对应的，缺一不可）
# 2. x轴应该是一个有序的，如果不是有序的，可以使用散点图绘制
x = np.array([0,10,8,2,1,4,6,3,9,5])
y = x*2 + np.sin(x) - np.cos(x)
plt.plot(x,y)
```




    [<matplotlib.lines.Line2D at 0x1a0d5f8a2b0>]




![png](output_7_1.png)



```python
x = np.random.randint(0,100,size=30)
s = Series(data=x)
s
```




    0      8
    1     10
    2     49
    3     11
    4     41
    5     87
    6     29
    7     12
    8     38
    9     58
    10    58
    11    74
    12    24
    13    55
    14    34
    15     7
    16     0
    17    11
    18    15
    19    29
    20    73
    21    97
    22    97
    23    25
    24    88
    25    29
    26    60
    27    59
    28     5
    29    86
    dtype: int32




```python
s.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a0d5fb35f8>




![png](output_9_1.png)



```python
x = np.arange(0,10,0.1)
print(x)
y1 = np.sin(x)
y2 = np.cos(x)
y3 = np.sin(x) + np.cos(x)

plt.plot(x,y1,x,y2,x,y3)
```

    [0.  0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.  1.1 1.2 1.3 1.4 1.5 1.6 1.7
     1.8 1.9 2.  2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.  3.1 3.2 3.3 3.4 3.5
     3.6 3.7 3.8 3.9 4.  4.1 4.2 4.3 4.4 4.5 4.6 4.7 4.8 4.9 5.  5.1 5.2 5.3
     5.4 5.5 5.6 5.7 5.8 5.9 6.  6.1 6.2 6.3 6.4 6.5 6.6 6.7 6.8 6.9 7.  7.1
     7.2 7.3 7.4 7.5 7.6 7.7 7.8 7.9 8.  8.1 8.2 8.3 8.4 8.5 8.6 8.7 8.8 8.9
     9.  9.1 9.2 9.3 9.4 9.5 9.6 9.7 9.8 9.9]
    




    [<matplotlib.lines.Line2D at 0x1a0d61178d0>,
     <matplotlib.lines.Line2D at 0x1a0d613da20>,
     <matplotlib.lines.Line2D at 0x1a0d613df60>]




![png](output_10_2.png)



```python
data = np.random.randint(0,100,size=(5,5))
index = [1,2,3,4,5]
columns = list('ABCDE')
df = DataFrame(data=data,index=index,columns=columns)
print(df)
df.plot()
```

        A   B   C   D   E
    1  74  60  24  45  93
    2  31  59  36  72  79
    3  29   1  82  85  31
    4  34  27  96  39  40
    5  79  60  78  60  52
    




    <matplotlib.axes._subplots.AxesSubplot at 0x1a0d72080f0>




![png](output_11_2.png)



```python
plt.plot(df.index,df['A'],df.index,df['B'],df.index,df['C'])
```




    [<matplotlib.lines.Line2D at 0x1a0d72b7a20>,
     <matplotlib.lines.Line2D at 0x1a0d72b7f28>,
     <matplotlib.lines.Line2D at 0x1a0d72b7eb8>]




![png](output_12_1.png)


1、可以使用多个plot函数（推荐），在一个图中绘制多个曲线

2、也可以在一个plot函数中传入多对X,Y值，在一个图中绘制多个曲线

### 设置子画布

axes = plt.subplot()


```python
# 设置画布大小
plt.figure(figsize=(10,10))

# 获取子画布
axes1 = plt.subplot(221)
x = np.linspace(-np.pi,np.pi,100)
y = np.sin(x)
axes1.plot(x,y)
# plt.plot(x,y)

axes2 = plt.subplot(222)
axes2.plot(x,np.tan(x))

axes3 = plt.subplot(2,2,3)
axes3.plot(x,np.tanh(x))

axes4 = plt.subplot(224)
axes4.plot(x,np.cos(x))
```




    [<matplotlib.lines.Line2D at 0x1a0d8b3e198>]




![png](output_16_1.png)


# 网格线
绘制正弦余弦

使用plt.grid方法可以开启网格线，使用plt面向对象的方法，创建多个子图显示不同网格线
![](1.PNG)

- lw代表linewidth，线的粗细
- alpha表示线的明暗程度
- color代表颜色
- axis显示轴向



```python
plt.grid(lw=3,ls='-.',color='red',alpha=0.5,axis='y')
# 可以省略on
# plt.grid('on')
plt.plot(x,np.sin(x))
```




    [<matplotlib.lines.Line2D at 0x1a0da8e5550>]




![png](output_19_1.png)



```python
figure = plt.figure(figsize=(12,8))

# 设置刻度线宽度和透明度
axes1 = plt.subplot(2,2,1)
axes1.grid(linewidth=3,alpha=0.3)

# red green yellow blue black purple cyan orange gray 。。。
# #00aaff
axes2 = plt.subplot(2,2,2)
axes2.grid(color='#00aaff')

axes2.plot(x,np.sin(x))

# 设置轴向
axes3 = plt.subplot(2,2,3)
axes3.grid(axis='x')
# 设置刻度线样式
axes4 = plt.subplot(2,2,4)
# '-'：实线
# '--'：虚线
# ':'：点线
# '-.'：点划线
axes4.grid(linestyle = '--')
axes4.plot(x,np.cos(x))

```




    [<matplotlib.lines.Line2D at 0x1a0daead7f0>]




![png](output_20_1.png)


### 坐标轴界限

plt.axis([xmin,xmax,ymin,ymax])


```python
x = np.arange(0,10,1)
y = x**2

plt.plot(x,y)
plt.axis([-10,10,-100,100])
```




    [-10, 10, -100, 100]




![png](output_23_1.png)


##### plt.axis('xxx') 'tight'、'off'、'equal'……

设置坐标轴类型  
关闭坐标轴
![](2.png)


```python
# plt.axis() 的常用用法有以下几种：
# plt.axis()：不带参数调用该函数会返回当前图形的坐标轴范围，返回值为一个包含四个元素的列表 [xmin, xmax, ymin, ymax]，表示 x 轴和 y 轴的最小值和最大值。
# plt.axis([xmin, xmax, ymin, ymax])：带参数调用可以设置坐标轴的范围，其中 xmin 是 x 轴的最小值，xmax 是 x 轴的最大值，ymin 是 y 轴的最小值，ymax 是 y 轴的最大值。
# plt.axis('equal')：设置 x 轴和 y 轴的比例尺相等，即保持图形的长宽比例一致。
# plt.axis('scaled')：同样是设置 x 轴和 y 轴的比例尺相等，保持图形的长宽比例一致。
# plt.axis('off')：关闭坐标轴的显示。
```


```python
# plt.figure(figsize=(8,4))
x = np.linspace(-1,1,100)
y = (1-x**2)**0.5
plt.plot(x,y)
# off 关闭坐标轴显示，equal\scaled 设置两个轴比例一致
plt.axis('off')
```




    (-1.1, 1.1, -0.04999744917480639, 1.0499464326709342)




![png](output_26_1.png)


#### xlim方法和ylim方法

除了plt.axis方法，还可以通过xlim，ylim方法设置坐标轴范围


```python
# plt.xlim([-5,5])
# plt.ylim([-8,8])

# 使用画布对象设置坐标轴界限
axes1 = plt.subplot(1,1,1)
axes1.set_xlim([-3,3])
axes1.set_ylim([-8,8])
# axes1.axis([-3,3,-5,5])
```




    (-8, 8)




![png](output_28_1.png)


### 坐标轴标签
xlabel方法和ylabel方法  
plt.ylabel('y = x^2 + 5',rotation = 60)旋转

- color 标签颜色
- fontsize 字体大小
- rotation 旋转角度



```python
plt.xlabel('X-label',fontsize=16,color='#00aaff')
# 设置旋转角度
plt.ylabel('Y-label',rotation=0)
```




    Text(0,0.5,'Y-label')




![png](output_30_1.png)



```python
axes = plt.subplot(111)
axes.set_xlabel('X-label')
axes.set_ylabel('Y_label')
```




    Text(0,0.5,'Y_label')




![png](output_31_1.png)


### 标题
plt.title()方法

- loc {left,center,right}
- color 标签颜色
- fontsize 字体大小
- rotation 旋转角度


```python
axes = plt.subplot(111)

# 设置子画布标题
axes.set_title('TITLE',loc='left',color='red',fontsize=18,rotation=45)
# 还有画布标题，注意区分

# plt.title('TITLE2')
```




    Text(0,1,'TITLE')




![png](output_33_1.png)


### 图例

#### legend方法

两种传参方法：
- 分别在plot函数中增加label参数,再调用legend()方法显示
- 直接在legend方法中传入字符串列表
![](3.png)



```python
# 第一种设置方式
x = np.arange(0,11,1)
plt.plot(x,x/2,label='slow')
plt.plot(x,x,label='normal')
plt.plot(x,x*2,label='fast')
# 设置图例的方法
plt.legend()
```




    <matplotlib.legend.Legend at 0x1a0dc35b748>




![png](output_36_1.png)



```python
# 第二种方法
plt.plot(x,x/2,x,x,x,x*2)
plt.legend(['slow','normal','fast'])
```




    <matplotlib.legend.Legend at 0x1a0db097cc0>




![png](output_37_1.png)



```python
# 使用画布对象设置
axes = plt.subplot(111)
# 设置线的风格，图例也会随着变化
axes.plot(x,x/2,label='slow',linestyle='-.')
axes.plot(x,x,label='normal',ls=':')
axes.plot(x,x*2,label='fast',ls='--')
axes.legend(loc=(0,1),ncol=3)
```




    <matplotlib.legend.Legend at 0x1a0dca55e80>




![png](output_38_1.png)


### loc参数

- loc参数用于设置图例标签的位置，一般在legend函数内
- matplotlib已经预定义好几种数字表示的位置

| 字符串       | 数值      | 字符串   |  数值 |
| :-------------: |:-----------:| :-----:|  :-----:|
| best        |  0        | center left   |   6 |
| upper right    | 1        | center right  |   7  |
| upper left    |  2        | lower center  |   8  |
| lower left    |  3        | upper center  |   9 |
| lower right   |  4        | center      |   10 |
| right       |  5        |

loc参数可以是2元素的元组，表示图例左下角的坐标

- [0,0] 左下
- [0,1] 左上
- [1,0] 右下
- [1,1] 右上

图例也可以超过图的界限loc = (-0.1,0.9)

### ncol参数
ncol控制图例中有几列,在legend中设置ncol,需要设置loc

### linestyle、color、marker
修改线条样式  
![](4.png)

### 保存图片

使用figure对象的savefig的函数
+ filename  
含有文件路径的字符串或Python的文件型对象。图像格式由文件扩展名推断得出，例如，.pdf推断出PDF，.png推断出PNG
（“png”、“pdf”、“svg”、“ps”、“eps”……）
+ dpi  
图像分辨率（每英寸点数），默认为100
+ facecolor  
图像的背景色，默认为“w”（白色） 


```python
figure = plt.figure()

x = np.linspace(-np.pi,np.pi,100)
axes = plt.subplot(111)
axes.plot(x,np.sin(x))

figure.savefig('sin.png',dpi=100,facecolor='cyan')
```


![png](output_47_0.png)


## 二、设置plot的风格和样式
plot语句中支持除X,Y以外的参数，以字符串形式存在，来控制颜色、线型、点型等要素，语法形式为：  
plt.plot(X, Y, 'format', ...) 

### 点和线的样式


```python
axes = plt.subplot(111,facecolor='pink')
x = np.linspace(-np.pi,np.pi,10)
lines = plt.plot(x,np.sin(x),x,np.cos(x),ls='steps')
line1 = lines[0]
line1.set_color('red')
line1.set_linestyle(':')


line2 = lines[1]
line2.set_c((0.1, 0.3, 0.8))
line2.set_alpha(0.1)
```


![png](output_50_0.png)


#### 颜色
参数color或c

##### 颜色值的方式
+ 别名
    + color='r'
    
    
    
+ 合法的HTML颜色名
    + color = 'red'

| 颜色       | 别名      | HTML颜色名  | 颜色   |  别名 |HTML颜色名|
| :-------------: |:---------:|:-----------:| :------:|  :-----:| :-----:|
| 蓝色        | b       | blue      | 绿色   |  g   |  green  |
| 红色        | r       | red      | 黄色    |  y   |  yellow |
| 青色        | c       | cyan      | 黑色   |  k   |  black  |
| 洋红色      | m        | magenta    | 白色   |  w   |  white  |






+ HTML十六进制字符串
    + color = '#eeefff'       




+ 归一化到[0, 1]的RGB元组
    + color = (0.3, 0.3, 0.4)


+ jpg png 区别


```python
# jpg是由0-255之间的数来表示颜色
# png  r/255.0 g/255.0  b/255.0

# 总结：

# 在JPG图像中，颜色通常以0-255的整数表示。
# 在PNG图像中，颜色通常以0.0-1.0的浮点数表示，这是通过将RGB通道中的整数值除以255得到的。
```


```python
# 0-255 0-255 0-255
data1 = plt.imread('林志玲.jpeg')
```


```python
plt.imshow(data1)
```




    <matplotlib.image.AxesImage at 0x1a0ddca26d8>




![png](output_55_1.png)



```python
data1.dtype
```




    dtype('uint8')




```python
plt.imsave('meizi.png',data1)
```


```python
data2 = plt.imread('meizi.png')
```


```python
data2.dtype
```




    dtype('float32')




```python
# JPG和PNG是两种常见的图像文件格式，它们在压缩算法、图像质量和透明度支持等方面有所不同。

# JPG（JPEG）是一种有损压缩的图像格式，它可以在一定程度上减小图像文件的大小。这种压缩是通过减少图像中的细节和颜色信息来实现的，因此可以在较小的文件尺寸下存储高分辨率的图像。JPG文件适合用于存储照片、图像和其他现实场景的图像，因为它可以在一定程度上保持较好的视觉质量。然而，由于有损压缩的特性，每次保存和重新保存JPG图像都会损失一些细节和图像质量。

# PNG是一种无损压缩的图像格式，它使用一种不会导致图像质量损失的压缩算法。PNG文件适合用于存储需要保持较高质量的图像，尤其是图形、图标和透明背景的图像。与JPG不同，PNG支持透明度通道，可以实现图像中的透明部分。这使得PNG成为在网页设计和图像编辑中广泛使用的文件格式。然而，由于无损压缩的特性，PNG图像文件的大小通常比同样尺寸的JPG图像文件要更大。

# 总结：

# JPG是有损压缩的图像格式，可以在一定程度上减小文件大小，但会损失一些细节和图像质量。适合存储照片和现实场景的图像。
# PNG是无损压缩的图像格式，保持较高的图像质量和细节。支持透明通道，适合存储图形、图标和需要保持高质量的图像。
# 选择使用JPG还是PNG取决于你的需求。如果你想要较小的文件大小并可以容忍一定的图像质量损失，可以选择JPG。如果你需要保持较高的图像质量、透明背景或具有图形和图标元素的图像，选择PNG可能更合适。

# 需要注意的是，无论选用哪种格式，每次保存和重新保存图像都可能导致进一步的损失，因此建议在需要编辑或修改图像时使用原始无损格式（如BMP或RAW）保存。
```

##### 透明度
alpha参数 

##### 背景色
设置背景色，通过plt.subplot()方法传入facecolor参数，来设置坐标系的背景色

#### 线型
参数linestyle或ls

| 线条风格     | 描述      | 线条风格 |  描述 |
| :-------------: |:------------:| :----:|  :-----:|
| '-'        | 实线     | ':'     |  虚线 |
| '--'       | 破折线    | 'steps'  |  阶梯线 |
| '-.'       | 点划线    | 'None' / '，' |  什么都不画 |

##### 线宽
linewidth或lw参数

##### 不同宽度的破折线
dashes参数    eg.dashes = [20,50,5,2,10,5]


设置破折号序列各段的宽度  
![](5.png)


```python
x = np.arange(0,100,1)
y = np.sin(0.1*x)
plt.plot(x,y,dashes=[2,5,10,5])
```




    [<matplotlib.lines.Line2D at 0x1a0dde4dd30>]




![png](output_67_1.png)


#### 点型
- marker 设置点形
- markersize 设置点形大小

| 标记        | 描述       | 标记   |  描述 |
| :-------------: |:-----------:| :----:|  :-----:|
| '1'         | 一角朝下的三脚架      | '3'     |  一角朝左的三脚架 |
| '2'         | 一角朝上的三脚架      | '4'     |  一角朝右的三脚架 |


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='4',markersize=20)
```




    [<matplotlib.lines.Line2D at 0x1a0ddeaeef0>]




![png](output_70_1.png)


| 标记        | 描述       | 标记   |  描述 |
| :-------------: |:-----------:| :----:|  :-----:|
| 's'         | 正方形   | 'p'   | 五边形     | 
| 'h'         | 六边形1    | 'H'     | 六边形2    |
| '8'         | 八边形     | 


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='8',markersize=20)
```




    [<matplotlib.lines.Line2D at 0x1a0ddf18080>]




![png](output_72_1.png)


| 标记        | 描述       | 标记   |  描述 |
| :-------------: |:-----------:| :----:|  :-----:|
| '.'     |  点 | 'x'   | X   |
| '\*'    |  星号  | '+'         | 加号       |
| ','         | 像素       |


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='*',markersize=20)
```




    [<matplotlib.lines.Line2D at 0x1a0ddf7e3c8>]




![png](output_74_1.png)


| 标记        | 描述       | 标记   |  描述 |
| :-------------: |:-----------:| :----:|  :-----:|
| 'o'         | 圆圈      | 'D'         | 菱形      |
| 'd'    |  小菱形  |'','None',' ',None| 无       | 


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='D',markersize=20)
```




    [<matplotlib.lines.Line2D at 0x1a0de84da90>]




![png](output_76_1.png)


| 标记     | 描述     | 标记   |  描述 |
| :--------: |:----------:| :------:| :----:|
| '\_'     |  水平线    | '&#124;'     |  竖线   
![](6.png)


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='_',markersize=20)
```




    [<matplotlib.lines.Line2D at 0x1a0de8afcc0>]




![png](output_78_1.png)


| 标记        | 描述       | 标记   |  描述 |
| :-------------: |:-----------:| :----:|  :-----:|
| 'v'         | 一角朝下的三角形 | '<'     |  一角朝左的三角形 |
| '^'         | 一角朝上的三角形 | '>'     |  一角朝右的三角形 |


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='>',markersize=20)
```




    [<matplotlib.lines.Line2D at 0x1a0de91a160>]




![png](output_80_1.png)


#### 多参数连用
颜色、点型、线型，可以把几种参数写在一个字符串内进行设置 'r-.o'


```python
x = np.arange(-10,10,1)
y = x+np.sin(x)*np.cos(x)
# plt.plot(x,y,marker='o',linestyle='-.',color='r')
plt.plot(x,y,'r-.o',x,x*2,'b:s')
```




    [<matplotlib.lines.Line2D at 0x1a0de978908>,
     <matplotlib.lines.Line2D at 0x1a0de978ac8>]




![png](output_82_1.png)


#### 更多点和线的设置

- markeredgecolor = 'green',
- markeredgewidth = 2,
- markerfacecolor = 'purple'


```python
x = np.linspace(-np.pi,np.pi,10)
plt.plot(x,np.sin(x),marker='H',markersize=20,markeredgecolor='r',markeredgewidth=2,markerfacecolor='yellow')
```




    [<matplotlib.lines.Line2D at 0x1a0de9ba470>]




![png](output_84_1.png)


| 参数        | 描述       | 参数       |  描述   |
| :-------------: |:-----------:| :-------------:|  :------:|
| color或c      | 线的颜色   | linestyle或ls  |  线型   |
| linewidth或lw   | 线宽     | marker       |  点型  |
| markeredgecolor  | 点边缘的颜色 | markeredgewidth | 点边缘的宽度 |
| markerfacecolor  | 点内部的颜色 | markersize    |  点的大小    |  
![](7.png)

#### 在一条语句中为多个曲线进行设置

##### 多个曲线同一设置
属性名声明，不可以多参数连用

plt.plot(x1, y1, x2, y2, fmt, ...)

##### 多个曲线不同设置
多个都进行设置时，多参数连用
plt.plot(x1, y1, fmt1, x2, y2, fmt2, ...)


```python
x = np.arange(0,100,5)
plt.plot(x,x,'r-.o',x,x/2,'b:2',x,x*2,'g--_')
```




    [<matplotlib.lines.Line2D at 0x1a0dea43630>,
     <matplotlib.lines.Line2D at 0x1a0dea43748>,
     <matplotlib.lines.Line2D at 0x1a0dea43c50>]




![png](output_89_1.png)



```python
plt.plot(x,x,ls='--',lw=2,markersize=10,marker='H')
```




    [<matplotlib.lines.Line2D at 0x1a0dea86588>]




![png](output_90_1.png)


#### 三种设置方式

##### 向方法传入关键字参数

- import matplotlib as mpl

##### 对实例使用一系列的setter方法

- plt.plot()方法返回一个包含所有线的列表，设置每一个线需要获取该线对象
    - eg: lines = plt.plot();   line = lines[0]
    - line.set_linewith()
    - line.set_linestyle()
    - line.set_color()
    
##### 对坐标系使用一系列的setter方法
- axes = plt.subplot()获取坐标系
    - set_title()
    - set_facecolor()
    - set_xticks、set_yticks 设置刻度值
    - set_xticklabels、set_yticklabels  设置刻度名称

### X、Y轴坐标刻度
plt.xticks()和plt.yticks()方法  

- 需指定刻度值和刻度名称  plt.xticks([刻度列表],[名称列表])
- 支持fontsize、rotation、color等参数设置
![](8.png)


```python
x = np.linspace(-np.pi,np.pi,100)
y = np.sin(x)
plt.plot(x,y)
# 设置y轴的刻度
plt.yticks([-1,0,1],['min',0,'max'])
plt.xticks([-np.pi,-np.pi/2,0,np.pi/2,np.pi],['-$\pi$','-β/2',0,'π/2','π'])
```




    ([<matplotlib.axis.XTick at 0x1a0deadb2b0>,
      <matplotlib.axis.XTick at 0x1a0deae1c88>,
      <matplotlib.axis.XTick at 0x1a0deae19e8>,
      <matplotlib.axis.XTick at 0x1a0deaffcf8>,
      <matplotlib.axis.XTick at 0x1a0deb08208>],
     <a list of 5 Text xticklabel objects>)




![png](output_95_1.png)



```python
axes = plt.subplot(111)
axes.plot(x,y)

# 使用画布对象设置坐标轴刻度及刻度标签
axes.set_xticks([-np.pi,-np.pi/2,0,np.pi/2,np.pi])
axes.set_xticklabels(['-π','-π/2',0,'π/2','π'])
```




    [Text(0,0,'-π'),
     Text(0,0,'-π/2'),
     Text(0,0,'0'),
     Text(0,0,'π/2'),
     Text(0,0,'π')]




![png](output_96_1.png)


#### 正弦余弦
LaTex语法，用$\pi$、$\sigma$等表达式在图表上写上希腊字母  

![](9.png)

## 三、2D图形


```python
# plt.hist(x, bins=5)利用Matplotlib绘制了数组x的直方图，并将数据分为5个条形桶（bins），也就是将数据分成了5个区间。

# 直方图以条形的形式表示了x中数据在每个区间的出现频率或数量。每个区间的宽度是根据数据范围和分布自动计算的，并且每个条形的高度表示该区间内数据的数量或频率。
```


```python
x = np.random.randint(0,10,10)
display(x)
plt.hist(x,bins=5)
```


    array([4, 0, 6, 0, 7, 1, 8, 5, 4, 9])





    (array([3., 0., 3., 2., 2.]),
     array([0. , 1.8, 3.6, 5.4, 7.2, 9. ]),
     <a list of 5 Patch objects>)




![png](output_100_2.png)



```python
x = np.random.randn(1000)
state = plt.hist(x,bins=100,normed=True,orientation='vertical',color='blue')
Series(x).plot(kind='kde',color='red')
```

    D:\software\Anaconda3\lib\site-packages\matplotlib\axes\_axes.py:6571: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "
    




    <matplotlib.axes._subplots.AxesSubplot at 0x1a0e5b8d908>




![png](output_101_2.png)


### 直方图

【直方图的参数只有一个x！！！不像条形图需要传入x,y】

hist()的参数
+ bins  
可以是一个bin数量的整数值，也可以是表示bin的一个序列。默认值为10
+ normed  
如果值为True，直方图的值将进行归一化处理，形成概率密度，默认值为False
+ color  
指定直方图的颜色。可以是单一颜色值或颜色的序列。如果指定了多个数据集合，颜色序列将会设置为相同的顺序。如果未指定，将会使用一个默认的线条颜色
+ orientation  
通过设置orientation为horizontal创建水平直方图。默认值为vertical

### 条形图

【条形图有两个参数x,y】

- width 纵向设置条形宽度
- height 横向设置条形高度

bar()、barh()


```python
x = np.arange(0,10,1)
height = np.random.randint(0,100,size=10)

plt.barh(x,height)
```




    <BarContainer object of 10 artists>




![png](output_104_1.png)


### 饼图

【饼图也只有一个参数x！】

pie()  
饼图适合展示各部分占总体的比例，条形图适合比较各部分的大小


```python
x = np.array([15,23])
plt.pie(x)
```




    ([<matplotlib.patches.Wedge at 0x1a0e5e246a0>,
      <matplotlib.patches.Wedge at 0x1a0e5e24be0>],
     [Text(0.357169,1.0404,''), Text(-0.357169,-1.0404,'')])




![png](output_106_1.png)


普通各部分占满饼图

普通未占满饼图


```python
x = np.array([0.3,0.5,0.1])
plt.pie(x)
```




    ([<matplotlib.patches.Wedge at 0x1a0e5e612e8>,
      <matplotlib.patches.Wedge at 0x1a0e5e61828>,
      <matplotlib.patches.Wedge at 0x1a0e5e61d68>],
     [Text(0.646564,0.889919,''),
      Text(-1.04616,-0.339919,''),
      Text(0.646564,-0.889919,'')])




![png](output_109_1.png)


饼图阴影、分裂等属性设置
- labels参数设置每一块的标签；
- labeldistance参数设置标签距离圆心的距离（比例值,只能设置一个浮点小数）
- autopct参数设置比例值的显示格式(%1.1f%%)；
- pctdistance参数设置比例值文字距离圆心的距离
- explode参数设置每一块顶点距圆形的长度（比例值,列表）；
- colors参数设置每一块的颜色（列表）；
- shadow参数为布尔值，设置是否绘制阴影
- startangle参数设置饼图起始角度


```python
x = np.array([13,16,29,20])
# 如何在matplotlib中显示汉字
data = plt.pie(x,labels=['first','second','third','fourth'],
               labeldistance=0.8,
               autopct='%1.3f%%',
               pctdistance=0.3,
              explode=[0,0,0.2,0],
              colors=['#00aaff','#aaff00','#ffaa11','#aa99ff'],
              shadow=True,startangle=90)
```


![png](output_111_0.png)


## 散点图

【散点图需要两个参数x,y，但此时x不是表示x轴的刻度，而是每个点的横坐标！】

scatter()  
![](10.png)


```python
x = np.random.randn(1000)
y = np.random.randn(1000)
s = np.random.randint(10,90,size=1000)
# r g b [0.3,0.4,0.1]
color = np.random.random(size=(1000,3))
# s=s指定了散点的尺寸（大小）。具体来说，通过s=s将数组s用作指定每个散点的大小。数组s包含了1000个整数，这些整数是从10到90之间随机抽取的。
plt.scatter(x,y,marker='d',s=s,color=color,alpha=0.8)
```




    <matplotlib.collections.PathCollection at 0x1a0e605a5f8>




![png](output_113_1.png)


## <font color = red>四、图形内的文字、注释、箭头(自学)</font>

控制文字属性的方法:  


| pyplot函数     | API方法                | 描述                     |
| :-------------: |:------------------------------:| :---------------------------------:|
| text()       |  mpl.axes.Axes.text()       | 在Axes对象的任意位置添加文字     |
| xlabel()      |  mpl.axes.Axes.set_xlabel()   | 为X轴添加标签               |
| ylabel()      |  mpl.axes.Axes.set_ylabel()   | 为Y轴添加标签               |
| title()       | mpl.axes.Axes.set_title()   |  为Axes对象添加标题            |
| legend()      | mpl.axes.Axes.legend()      |  为Axes对象添加图例            |
| figtext()     |  mpl.figure.Figure.text()    |  在Figure对象的任意位置添加文字    |
| suptitle()     | mpl.figure.Figure.suptitle() |  为Figure对象添加中心化的标题     |
| annnotate()    |  mpl.axes.Axes.annotate()    |  为Axes对象添加注释（箭头可选）    |  


所有的方法会返回一个matplotlib.text.Text对象


```python
axes = plt.subplot(111)
axes.text(x=0.1,y=0.9,s='annotation')
```




    Text(0.1,0.9,'annotation')




![png](output_116_1.png)



```python
figure = plt.figure()
axes1 = plt.subplot(1,2,1)
axes1.scatter(x,y)
axes1.set_title('axes1-title')

axes2 = plt.subplot(1,2,2)
axes2.plot(x,y)
axes2.set_title('axes2-title')

figure.text(x=0.1,y=0.9,s='figure text')
figure.suptitle('figure title')
```




    Text(0.5,0.98,'figure title')




![png](output_117_1.png)


### 图形内的文字
text()  
![](14.png)

### 注释
annotate()
- xy参数设置箭头指示的位置
- xytext参数设置注释文字的位置  
- arrowprops参数以字典的形式设置箭头的样式  
- width参数设置箭头长方形部分的宽度
- headlength参数设置箭头尖端的长度，  
- headwidth参数设置箭头尖端底部的宽度
- shrink参数设置箭头顶点、尾部与指示点、注释文字的距离（比例值），可以理解为控制箭头的长度
![](15.png)

    如下都是arrowstyle可以选择的风格样式
    
    ``'->'``       head_length=0.4,head_width=0.2
    ``'-['``       widthB=1.0,lengthB=0.2,angleB=None
    ``'|-|'``      widthA=1.0,widthB=1.0
    ``'-|>'``      head_length=0.4,head_width=0.2
    ``'<-'``       head_length=0.4,head_width=0.2
    ``'<->'``      head_length=0.4,head_width=0.2
    ``'<|-'``      head_length=0.4,head_width=0.2
    ``'<|-|>'``    head_length=0.4,head_width=0.2
    ``'fancy'``    head_length=0.4,head_width=0.4,tail_width=0.4
    ``'simple'``   head_length=0.5,head_width=0.5,tail_width=0.2
    ``'wedge'``    tail_width=0.3,shrink_factor=0.5



```python
x = np.arange(0,14,1)
y = np.random.randint(0,15,size=14)

y[4] = 33
axes = plt.subplot(111)
axes.plot(x,y)
axes.set_ylim([0,40])

# 第一种情况，arrowprops字典包含arrowstyle键，可以使用预定义的箭头样式
# axes.annotate(s='annotation',xy=[4,34],xytext=[6,36],arrowprops={'arrowstyle':'simple'})
# 第二种情况，arrowprops字典不包含arrowstyle键，可以自定义箭头样式
axes.annotate(s='annotation',xy=[4,34],xytext=[6,36],
              arrowprops={'width':7,'headlength':20,'headwidth':10,'shrink':0.2})
```




    Text(6,36,'annotation')




![png](output_121_1.png)


练习  
三个随机正太分布数据
![](16.png)  

## <font color = red>五、3D图(自学)</font>

#### 曲面图  
![](11.png)

导包  
- from mpl_toolkits.mplot3d.axes3d import Axes3D

使用mershgrid函数切割x,y轴
- X,Y = np.meshgrid(x, y)

创建3d坐标系
- axes = plt.subplot(projection='3d')

绘制3d图形
- p = axes.plot_surface(X,Y,Z,color='red',cmap='summer',rstride=5,cstride=5)

添加colorbar
- plt.colorbar(p,shrink=0.5)


```python
from mpl_toolkits.mplot3d.axes3d import Axes3D
plt.figure(figsize=(12,8))
axes = plt.subplot(projection='3d')

x = np.linspace(-np.pi,np.pi,100)
y = np.linspace(-np.pi,np.pi,100)
XX,YY = np.meshgrid(x, y)

def creat_Z(XX,YY):
    return np.sin(XX) + np.cos(YY)

ZZ = creat_Z(XX,YY)

# 
p = axes.plot_surface(XX,YY,ZZ,color='#ff00aa',cmap='spring',rstride=5,cstride=10)

plt.colorbar(p,shrink=0.5)
```




    <matplotlib.colorbar.Colorbar at 0x1a0e0b0de48>




![png](output_126_1.png)


## <font color = red>玫瑰图/极坐标条形图(自学)</font>  
![](13.png)

创建极坐标，设置polar属性
- plt.axes(polar = True)

绘制极坐标条形图
- index = np.arange(-np.pi,np.pi,2*np.pi/6)
- plt.bar(x=index ,height = [1,2,3,4,5,6] ,width = 2*np.pi/6)


```python
plt.axes(polar=True)

index = [1,2,3,4,5]
height = [30,24,35,29,50]
plt.bar(x=index,height=height,width=0.8)
```




    <BarContainer object of 5 artists>




![png](output_129_1.png)



```python

```


```python

```

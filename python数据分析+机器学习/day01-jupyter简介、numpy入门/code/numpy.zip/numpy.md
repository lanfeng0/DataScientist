
# numpy get started

导入numpy库，并查看numpy版本


```python
import numpy as np
```

1. 是什么
2. 能干啥
3. 怎么用
4. 有什么注意
5. 扩展。。。

## 一、创建ndarray

### 1. 使用np.array()由python list创建


```python
arr1 = np.array([1,2,'3.0',4,6,7,9])
```


```python
display(arr1)
```


    array(['1', '2', '3.0', '4', '6', '7', '9'], dtype='<U11')



```python
[1,2,3,4,6,7,9]
```




    [1, 2, 3, 4, 6, 7, 9]



参数为列表：
[1, 4, 2, 5, 3]

注意：
- numpy默认ndarray的所有元素的类型是相同的
- 如果传进来的列表中包含不同的类型，则统一为同一类型，优先级：str>float>int

### 2. 使用np的routines函数创建

包含以下常见创建方法：

1) np.ones(shape, dtype=None, order='C')


```python
np.ones?
```


    [1;31mSignature:[0m [0mnp[0m[1;33m.[0m[0mones[0m[1;33m([0m[0mshape[0m[1;33m,[0m [0mdtype[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0morder[0m[1;33m=[0m[1;34m'C'[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Return a new array of given shape and type, filled with ones.
    
    Parameters
    ----------
    shape : int or sequence of ints
        Shape of the new array, e.g., ``(2, 3)`` or ``2``.
    dtype : data-type, optional
        The desired data-type for the array, e.g., `numpy.int8`.  Default is
        `numpy.float64`.
    order : {'C', 'F'}, optional, default: C
        Whether to store multi-dimensional data in row-major
        (C-style) or column-major (Fortran-style) order in
        memory.
    
    Returns
    -------
    out : ndarray
        Array of ones with the given shape, dtype, and order.
    
    See Also
    --------
    ones_like : Return an array of ones with shape and type of input.
    empty : Return a new uninitialized array.
    zeros : Return a new array setting values to zero.
    full : Return a new array of given shape filled with value.
    
    
    Examples
    --------
    >>> np.ones(5)
    array([ 1.,  1.,  1.,  1.,  1.])
    
    >>> np.ones((5,), dtype=int)
    array([1, 1, 1, 1, 1])
    
    >>> np.ones((2, 1))
    array([[ 1.],
           [ 1.]])
    
    >>> s = (2,2)
    >>> np.ones(s)
    array([[ 1.,  1.],
           [ 1.,  1.]])
    [1;31mFile:[0m      d:\software\anaconda3\lib\site-packages\numpy\core\numeric.py
    [1;31mType:[0m      function
    



```python
np.ones(shape=2,dtype=np.int)
```




    array([1, 1])




```python
np.ones(shape=(2,3))
```




    array([[1., 1., 1.],
           [1., 1., 1.]])



2) np.zeros(shape, dtype=float, order='C')


```python
np.zeros(shape=(3,3),dtype=np.int)
```




    array([[0, 0, 0],
           [0, 0, 0],
           [0, 0, 0]])



3) np.full(shape, fill_value, dtype=None, order='C')


```python
np.full?
```


    [1;31mSignature:[0m [0mnp[0m[1;33m.[0m[0mfull[0m[1;33m([0m[0mshape[0m[1;33m,[0m [0mfill_value[0m[1;33m,[0m [0mdtype[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0morder[0m[1;33m=[0m[1;34m'C'[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Return a new array of given shape and type, filled with `fill_value`.
    
    Parameters
    ----------
    shape : int or sequence of ints
        Shape of the new array, e.g., ``(2, 3)`` or ``2``.
    fill_value : scalar
        Fill value.
    dtype : data-type, optional
        The desired data-type for the array  The default, `None`, means
         `np.array(fill_value).dtype`.
    order : {'C', 'F'}, optional
        Whether to store multidimensional data in C- or Fortran-contiguous
        (row- or column-wise) order in memory.
    
    Returns
    -------
    out : ndarray
        Array of `fill_value` with the given shape, dtype, and order.
    
    See Also
    --------
    full_like : Return a new array with shape of input filled with value.
    empty : Return a new uninitialized array.
    ones : Return a new array setting values to one.
    zeros : Return a new array setting values to zero.
    
    Examples
    --------
    >>> np.full((2, 2), np.inf)
    array([[ inf,  inf],
           [ inf,  inf]])
    >>> np.full((2, 2), 10)
    array([[10, 10],
           [10, 10]])
    [1;31mFile:[0m      d:\software\anaconda3\lib\site-packages\numpy\core\numeric.py
    [1;31mType:[0m      function
    



```python
np.full(shape=(2,3),fill_value=6)
```




    array([[6, 6, 6],
           [6, 6, 6]])



4) np.eye(N, M=None, k=0, dtype=float)  
对角线为1其他的位置为0


```python
np.eye?
```


    [1;31mSignature:[0m [0mnp[0m[1;33m.[0m[0meye[0m[1;33m([0m[0mN[0m[1;33m,[0m [0mM[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mk[0m[1;33m=[0m[1;36m0[0m[1;33m,[0m [0mdtype[0m[1;33m=[0m[1;33m<[0m[1;32mclass[0m [1;34m'float'[0m[1;33m>[0m[1;33m,[0m [0morder[0m[1;33m=[0m[1;34m'C'[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Return a 2-D array with ones on the diagonal and zeros elsewhere.
    
    Parameters
    ----------
    N : int
      Number of rows in the output.
    M : int, optional
      Number of columns in the output. If None, defaults to `N`.
    k : int, optional
      Index of the diagonal: 0 (the default) refers to the main diagonal,
      a positive value refers to an upper diagonal, and a negative value
      to a lower diagonal.
    dtype : data-type, optional
      Data-type of the returned array.
    order : {'C', 'F'}, optional
        Whether the output should be stored in row-major (C-style) or
        column-major (Fortran-style) order in memory.
    
        .. versionadded:: 1.14.0
    
    Returns
    -------
    I : ndarray of shape (N,M)
      An array where all elements are equal to zero, except for the `k`-th
      diagonal, whose values are equal to one.
    
    See Also
    --------
    identity : (almost) equivalent function
    diag : diagonal 2-D array from a 1-D array specified by the user.
    
    Examples
    --------
    >>> np.eye(2, dtype=int)
    array([[1, 0],
           [0, 1]])
    >>> np.eye(3, k=1)
    array([[ 0.,  1.,  0.],
           [ 0.,  0.,  1.],
           [ 0.,  0.,  0.]])
    [1;31mFile:[0m      d:\software\anaconda3\lib\site-packages\numpy\lib\twodim_base.py
    [1;31mType:[0m      function
    



```python
# 单位矩阵
np.eye(N=4,M=4,k=-0)
```




    array([[1., 0., 0., 0.],
           [0., 1., 0., 0.],
           [0., 0., 1., 0.],
           [0., 0., 0., 1.]])



5) np.linspace(start, stop, num=50, endpoint=True, retstep=False, dtype=None)


```python
np.linspace?
```


    [1;31mSignature:[0m [0mnp[0m[1;33m.[0m[0mlinspace[0m[1;33m([0m[0mstart[0m[1;33m,[0m [0mstop[0m[1;33m,[0m [0mnum[0m[1;33m=[0m[1;36m50[0m[1;33m,[0m [0mendpoint[0m[1;33m=[0m[1;32mTrue[0m[1;33m,[0m [0mretstep[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0mdtype[0m[1;33m=[0m[1;32mNone[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Return evenly spaced numbers over a specified interval.
    
    Returns `num` evenly spaced samples, calculated over the
    interval [`start`, `stop`].
    
    The endpoint of the interval can optionally be excluded.
    
    Parameters
    ----------
    start : scalar
        The starting value of the sequence.
    stop : scalar
        The end value of the sequence, unless `endpoint` is set to False.
        In that case, the sequence consists of all but the last of ``num + 1``
        evenly spaced samples, so that `stop` is excluded.  Note that the step
        size changes when `endpoint` is False.
    num : int, optional
        Number of samples to generate. Default is 50. Must be non-negative.
    endpoint : bool, optional
        If True, `stop` is the last sample. Otherwise, it is not included.
        Default is True.
    retstep : bool, optional
        If True, return (`samples`, `step`), where `step` is the spacing
        between samples.
    dtype : dtype, optional
        The type of the output array.  If `dtype` is not given, infer the data
        type from the other input arguments.
    
        .. versionadded:: 1.9.0
    
    Returns
    -------
    samples : ndarray
        There are `num` equally spaced samples in the closed interval
        ``[start, stop]`` or the half-open interval ``[start, stop)``
        (depending on whether `endpoint` is True or False).
    step : float, optional
        Only returned if `retstep` is True
    
        Size of spacing between samples.
    
    
    See Also
    --------
    arange : Similar to `linspace`, but uses a step size (instead of the
             number of samples).
    logspace : Samples uniformly distributed in log space.
    
    Examples
    --------
    >>> np.linspace(2.0, 3.0, num=5)
    array([ 2.  ,  2.25,  2.5 ,  2.75,  3.  ])
    >>> np.linspace(2.0, 3.0, num=5, endpoint=False)
    array([ 2. ,  2.2,  2.4,  2.6,  2.8])
    >>> np.linspace(2.0, 3.0, num=5, retstep=True)
    (array([ 2.  ,  2.25,  2.5 ,  2.75,  3.  ]), 0.25)
    
    Graphical illustration:
    
    >>> import matplotlib.pyplot as plt
    >>> N = 8
    >>> y = np.zeros(N)
    >>> x1 = np.linspace(0, 10, N, endpoint=True)
    >>> x2 = np.linspace(0, 10, N, endpoint=False)
    >>> plt.plot(x1, y, 'o')
    [<matplotlib.lines.Line2D object at 0x...>]
    >>> plt.plot(x2, y + 0.5, 'o')
    [<matplotlib.lines.Line2D object at 0x...>]
    >>> plt.ylim([-0.5, 1])
    (-0.5, 1)
    >>> plt.show()
    [1;31mFile:[0m      d:\software\anaconda3\lib\site-packages\numpy\core\function_base.py
    [1;31mType:[0m      function
    



```python
# 指定元素个数来生成一个等差数列
np.linspace(start=0,stop=100,num=10,endpoint=False,retstep=True ,dtype=float)
```




    (array([ 0., 10., 20., 30., 40., 50., 60., 70., 80., 90.]), 10.0)



6) np.arange([start, ]stop, [step, ]dtype=None)


```python
np.arange?
```


    [1;31mDocstring:[0m
    arange([start,] stop[, step,], dtype=None)
    
    Return evenly spaced values within a given interval.
    
    Values are generated within the half-open interval ``[start, stop)``
    (in other words, the interval including `start` but excluding `stop`).
    For integer arguments the function is equivalent to the Python built-in
    `range <http://docs.python.org/lib/built-in-funcs.html>`_ function,
    but returns an ndarray rather than a list.
    
    When using a non-integer step, such as 0.1, the results will often not
    be consistent.  It is better to use ``linspace`` for these cases.
    
    Parameters
    ----------
    start : number, optional
        Start of interval.  The interval includes this value.  The default
        start value is 0.
    stop : number
        End of interval.  The interval does not include this value, except
        in some cases where `step` is not an integer and floating point
        round-off affects the length of `out`.
    step : number, optional
        Spacing between values.  For any output `out`, this is the distance
        between two adjacent values, ``out[i+1] - out[i]``.  The default
        step size is 1.  If `step` is specified as a position argument,
        `start` must also be given.
    dtype : dtype
        The type of the output array.  If `dtype` is not given, infer the data
        type from the other input arguments.
    
    Returns
    -------
    arange : ndarray
        Array of evenly spaced values.
    
        For floating point arguments, the length of the result is
        ``ceil((stop - start)/step)``.  Because of floating point overflow,
        this rule may result in the last element of `out` being greater
        than `stop`.
    
    See Also
    --------
    linspace : Evenly spaced numbers with careful handling of endpoints.
    ogrid: Arrays of evenly spaced numbers in N-dimensions.
    mgrid: Grid-shaped arrays of evenly spaced numbers in N-dimensions.
    
    Examples
    --------
    >>> np.arange(3)
    array([0, 1, 2])
    >>> np.arange(3.0)
    array([ 0.,  1.,  2.])
    >>> np.arange(3,7)
    array([3, 4, 5, 6])
    >>> np.arange(3,7,2)
    array([3, 5])
    [1;31mType:[0m      builtin_function_or_method
    



```python
# 指定步长来创建一个等差数列
np.arange(0,100,step=5)
```




    array([ 0,  5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80,
           85, 90, 95])



7) np.random.randint(low, high=None, size=None, dtype='l')


```python
np.random.randint?
```


    [1;31mDocstring:[0m
    randint(low, high=None, size=None, dtype='l')
    
    Return random integers from `low` (inclusive) to `high` (exclusive).
    
    Return random integers from the "discrete uniform" distribution of
    the specified dtype in the "half-open" interval [`low`, `high`). If
    `high` is None (the default), then results are from [0, `low`).
    
    Parameters
    ----------
    low : int
        Lowest (signed) integer to be drawn from the distribution (unless
        ``high=None``, in which case this parameter is one above the
        *highest* such integer).
    high : int, optional
        If provided, one above the largest (signed) integer to be drawn
        from the distribution (see above for behavior if ``high=None``).
    size : int or tuple of ints, optional
        Output shape.  If the given shape is, e.g., ``(m, n, k)``, then
        ``m * n * k`` samples are drawn.  Default is None, in which case a
        single value is returned.
    dtype : dtype, optional
        Desired dtype of the result. All dtypes are determined by their
        name, i.e., 'int64', 'int', etc, so byteorder is not available
        and a specific precision may have different C types depending
        on the platform. The default value is 'np.int'.
    
        .. versionadded:: 1.11.0
    
    Returns
    -------
    out : int or ndarray of ints
        `size`-shaped array of random integers from the appropriate
        distribution, or a single such random int if `size` not provided.
    
    See Also
    --------
    random.random_integers : similar to `randint`, only for the closed
        interval [`low`, `high`], and 1 is the lowest value if `high` is
        omitted. In particular, this other one is the one to use to generate
        uniformly distributed discrete non-integers.
    
    Examples
    --------
    >>> np.random.randint(2, size=10)
    array([1, 0, 0, 0, 1, 1, 0, 0, 1, 0])
    >>> np.random.randint(1, size=10)
    array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    
    Generate a 2 x 4 array of ints between 0 and 4, inclusive:
    
    >>> np.random.randint(5, size=(2, 4))
    array([[4, 0, 2, 1],
           [3, 2, 2, 0]])
    [1;31mType:[0m      builtin_function_or_method
    



```python
np.random.randint(0,100,size=5)
```




    array([24, 63, 27, 94, 70])




```python
np.random.randint(0,100,size=(2,3))
```




    array([[95, 37,  2],
           [21, 40, 78]])




```python
np.random.randint(0,100)
```




    45



8) np.random.randn(d0, d1, ..., dn)  

标准正太分布　

np.random.normal()


```python
np.random.randn?
```


    [1;31mDocstring:[0m
    randn(d0, d1, ..., dn)
    
    Return a sample (or samples) from the "standard normal" distribution.
    
    If positive, int_like or int-convertible arguments are provided,
    `randn` generates an array of shape ``(d0, d1, ..., dn)``, filled
    with random floats sampled from a univariate "normal" (Gaussian)
    distribution of mean 0 and variance 1 (if any of the :math:`d_i` are
    floats, they are first converted to integers by truncation). A single
    float randomly sampled from the distribution is returned if no
    argument is provided.
    
    This is a convenience function.  If you want an interface that takes a
    tuple as the first argument, use `numpy.random.standard_normal` instead.
    
    Parameters
    ----------
    d0, d1, ..., dn : int, optional
        The dimensions of the returned array, should be all positive.
        If no argument is given a single Python float is returned.
    
    Returns
    -------
    Z : ndarray or float
        A ``(d0, d1, ..., dn)``-shaped array of floating-point samples from
        the standard normal distribution, or a single such float if
        no parameters were supplied.
    
    See Also
    --------
    standard_normal : Similar, but takes a tuple as its argument.
    
    Notes
    -----
    For random samples from :math:`N(\mu, \sigma^2)`, use:
    
    ``sigma * np.random.randn(...) + mu``
    
    Examples
    --------
    >>> np.random.randn()
    2.1923875335537315 #random
    
    Two-by-four array of samples from N(3, 6.25):
    
    >>> 2.5 * np.random.randn(2, 4) + 3
    array([[-4.49401501,  4.00950034, -1.81814867,  7.29718677],  #random
           [ 0.39924804,  4.68456316,  4.99394529,  4.84057254]]) #random
    [1;31mType:[0m      builtin_function_or_method
    



```python
np.random.randn(2,3,3)
```




    array([[[-0.10583642,  0.59260669,  0.652262  ],
            [ 0.10750643, -0.12544582, -1.37010824],
            [-0.58185775,  0.53139466, -1.88358138]],
    
           [[-0.39970458,  0.61506971, -0.62935583],
            [-0.37010793,  0.14588707,  1.08841025],
            [ 2.38080223, -1.89634309, -0.2712082 ]]])




```python
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

# 定义均值和标准差
mu = 0
sigma = 1

# 生成正态分布随机数
samples = np.random.normal(mu, sigma, size=10000)

# 绘制直方图
plt.hist(samples, bins=50, density=True)

# 绘制正态分布的概率密度函数曲线
x = np.linspace(-5, 5, 100)
y = norm.pdf(x, mu, sigma)
plt.plot(x, y, 'r-', linewidth=2)
# 显示图形
plt.xlabel('Value')
plt.ylabel('Probability')
plt.title('Normal Distribution')
plt.show()
```


![png](output_38_0.png)



```python
np.random.normal?
```


    [1;31mDocstring:[0m
    normal(loc=0.0, scale=1.0, size=None)
    
    Draw random samples from a normal (Gaussian) distribution.
    
    The probability density function of the normal distribution, first
    derived by De Moivre and 200 years later by both Gauss and Laplace
    independently [2]_, is often called the bell curve because of
    its characteristic shape (see the example below).
    
    The normal distributions occurs often in nature.  For example, it
    describes the commonly occurring distribution of samples influenced
    by a large number of tiny, random disturbances, each with its own
    unique distribution [2]_.
    
    Parameters
    ----------
    loc : float or array_like of floats
        Mean ("centre") of the distribution.
    scale : float or array_like of floats
        Standard deviation (spread or "width") of the distribution.
    size : int or tuple of ints, optional
        Output shape.  If the given shape is, e.g., ``(m, n, k)``, then
        ``m * n * k`` samples are drawn.  If size is ``None`` (default),
        a single value is returned if ``loc`` and ``scale`` are both scalars.
        Otherwise, ``np.broadcast(loc, scale).size`` samples are drawn.
    
    Returns
    -------
    out : ndarray or scalar
        Drawn samples from the parameterized normal distribution.
    
    See Also
    --------
    scipy.stats.norm : probability density function, distribution or
        cumulative density function, etc.
    
    Notes
    -----
    The probability density for the Gaussian distribution is
    
    .. math:: p(x) = \frac{1}{\sqrt{ 2 \pi \sigma^2 }}
                     e^{ - \frac{ (x - \mu)^2 } {2 \sigma^2} },
    
    where :math:`\mu` is the mean and :math:`\sigma` the standard
    deviation. The square of the standard deviation, :math:`\sigma^2`,
    is called the variance.
    
    The function has its peak at the mean, and its "spread" increases with
    the standard deviation (the function reaches 0.607 times its maximum at
    :math:`x + \sigma` and :math:`x - \sigma` [2]_).  This implies that
    `numpy.random.normal` is more likely to return samples lying close to
    the mean, rather than those far away.
    
    References
    ----------
    .. [1] Wikipedia, "Normal distribution",
           http://en.wikipedia.org/wiki/Normal_distribution
    .. [2] P. R. Peebles Jr., "Central Limit Theorem" in "Probability,
           Random Variables and Random Signal Principles", 4th ed., 2001,
           pp. 51, 51, 125.
    
    Examples
    --------
    Draw samples from the distribution:
    
    >>> mu, sigma = 0, 0.1 # mean and standard deviation
    >>> s = np.random.normal(mu, sigma, 1000)
    
    Verify the mean and the variance:
    
    >>> abs(mu - np.mean(s)) < 0.01
    True
    
    >>> abs(sigma - np.std(s, ddof=1)) < 0.01
    True
    
    Display the histogram of the samples, along with
    the probability density function:
    
    >>> import matplotlib.pyplot as plt
    >>> count, bins, ignored = plt.hist(s, 30, density=True)
    >>> plt.plot(bins, 1/(sigma * np.sqrt(2 * np.pi)) *
    ...                np.exp( - (bins - mu)**2 / (2 * sigma**2) ),
    ...          linewidth=2, color='r')
    >>> plt.show()
    [1;31mType:[0m      builtin_function_or_method
    



```python
# 可以控制期望值和方差变化
# loc 期望值 默认0
# scale 方差 默认值1
np.random.normal(loc=10,scale=1,size=(2,3))
```




    array([[10.92802491, 10.24225241, 10.48425106],
           [10.38278543, 10.62420944,  9.67098901]])




```python
生成0到1的随机数，左闭右开
```


```python
np.random.random(size=None)  
```




    0.8583926826472478




```python
rgb  
png 0-255, 
jpg 0-1,
```


      File "<ipython-input-46-d1e351e37b74>", line 2
        png 0-255,
            ^
    SyntaxError: invalid syntax
    



```python
data = np.random.random(size=(100,100,3))
data
```




    array([[[0.65418597, 0.2700196 , 0.23165511],
            [0.7867505 , 0.38971393, 0.62555746],
            [0.3548321 , 0.87032478, 0.96644448],
            ...,
            [0.59256563, 0.97736529, 0.52882126],
            [0.80543935, 0.39466055, 0.82959128],
            [0.72814543, 0.65443308, 0.55965343]],
    
           [[0.7546528 , 0.87288159, 0.51276647],
            [0.28554325, 0.01556885, 0.81772363],
            [0.12231236, 0.79667926, 0.68331864],
            ...,
            [0.21335609, 0.29266716, 0.50525799],
            [0.82580366, 0.98966649, 0.07809795],
            [0.25998071, 0.55317283, 0.20081116]],
    
           [[0.3167381 , 0.59502087, 0.20884676],
            [0.93353569, 0.83670403, 0.9256678 ],
            [0.7143994 , 0.90320956, 0.70620502],
            ...,
            [0.16655306, 0.27876625, 0.23609562],
            [0.74802752, 0.28386717, 0.45175162],
            [0.10477416, 0.94580613, 0.69641286]],
    
           ...,
    
           [[0.24314776, 0.84782989, 0.44329267],
            [0.19675255, 0.52755653, 0.33124652],
            [0.83051066, 0.91354725, 0.99004919],
            ...,
            [0.94860945, 0.62375278, 0.27919423],
            [0.45124753, 0.08762156, 0.39366886],
            [0.16954712, 0.64460838, 0.99005145]],
    
           [[0.60686445, 0.56175066, 0.97077051],
            [0.3012273 , 0.40139865, 0.62891709],
            [0.91051341, 0.37164227, 0.72764244],
            ...,
            [0.07778488, 0.44498493, 0.08791673],
            [0.14911472, 0.38188035, 0.37260457],
            [0.99178638, 0.41303397, 0.60565964]],
    
           [[0.16373797, 0.6999885 , 0.42622335],
            [0.68681075, 0.96003711, 0.51590097],
            [0.49059042, 0.07965417, 0.0780799 ],
            ...,
            [0.05585858, 0.69176879, 0.76925859],
            [0.75172243, 0.98043546, 0.31651031],
            [0.76585682, 0.64550126, 0.6325963 ]]])




```python
np.random.random(size=30000).reshape((100,100,3))
```




    array([[[0.6826319 , 0.87854834, 0.97569183],
            [0.4917545 , 0.97000793, 0.02218712],
            [0.16466137, 0.10750201, 0.13820155],
            ...,
            [0.88038562, 0.59263362, 0.78935384],
            [0.45436731, 0.63109286, 0.35769642],
            [0.81436821, 0.6954347 , 0.24118947]],
    
           [[0.3673285 , 0.45102116, 0.19220529],
            [0.66163523, 0.47290552, 0.66762592],
            [0.44041354, 0.91945317, 0.15478431],
            ...,
            [0.16219479, 0.8845042 , 0.03949155],
            [0.6907301 , 0.51327087, 0.99703513],
            [0.35546738, 0.55011522, 0.26270904]],
    
           [[0.83761565, 0.62189635, 0.95606875],
            [0.68897572, 0.34752825, 0.54406083],
            [0.5895124 , 0.98636727, 0.98939395],
            ...,
            [0.3157356 , 0.86983587, 0.57103196],
            [0.85268977, 0.98727351, 0.66815945],
            [0.55962993, 0.25057477, 0.59840124]],
    
           ...,
    
           [[0.48836617, 0.78715634, 0.0177188 ],
            [0.16397329, 0.14865048, 0.86742895],
            [0.15771953, 0.2724908 , 0.07151551],
            ...,
            [0.58630016, 0.74279929, 0.63995387],
            [0.09127063, 0.35228384, 0.97068702],
            [0.46720064, 0.3304496 , 0.54317516]],
    
           [[0.75665799, 0.92168317, 0.25860895],
            [0.27836156, 0.77224073, 0.78664689],
            [0.94931154, 0.32077109, 0.35461148],
            ...,
            [0.24862618, 0.40031585, 0.57378882],
            [0.25613643, 0.39605797, 0.21149107],
            [0.80561228, 0.34516599, 0.86388149]],
    
           [[0.49778911, 0.08749693, 0.34969922],
            [0.54451559, 0.13235072, 0.80053516],
            [0.12422041, 0.55233201, 0.27550832],
            ...,
            [0.42844548, 0.08732305, 0.3574664 ],
            [0.44712477, 0.47760212, 0.07273556],
            [0.26703803, 0.41390822, 0.77327843]]])




```python
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
plt.imshow(data)
```




    <matplotlib.image.AxesImage at 0x24cd3371630>




![png](output_47_1.png)


## 二、ndarray的属性

4个必记参数：
ndim：维度
shape：形状（各维度的长度）
size：总长度

dtype：元素类型



```python
data.ndim
```




    3




```python
data.shape
```




    (100, 100, 3)




```python
data.size
```




    30000




```python
data.dtype
```




    dtype('float64')



## 三、ndarray的基本操作

### 1. 索引
一维与列表完全一致
多维时同理


```python
import numpy as np
```


```python
arr1 = np.random.randint(0,100,size=10)
```


```python
arr1
```




    array([36, 81, 31, 59, 10, 56, 48, 36, 82, 19])




```python
arr1[0] = 11
```


```python
arr1
```




    array([11, 81, 31, 59, 10, 56, 48, 36, 82, 19])




```python
arr1[-1]
```




    19




```python
arr1[[0,1,2]]
```




    array([11, 81, 31])




```python
arr2 = np.random.randint(0,100,size=(3,5))
arr2
```




    array([[46, 36, 77, 67, 25],
           [41, 76, 25, 48, 64],
           [58, 54, 81, 41,  6]])




```python
arr2[0][0]
```




    46




```python
arr3 = np.random.randint(0,100,size=(5,5,3))
arr3
```




    array([[[25, 16, 87],
            [34, 66, 67],
            [71, 84, 45],
            [ 1, 91, 83],
            [60, 79, 93]],
    
           [[63,  4, 90],
            [ 9, 64, 13],
            [20, 61,  9],
            [66, 60, 35],
            [21, 75,  9]],
    
           [[ 8, 18, 91],
            [74, 39, 37],
            [ 2, 62, 62],
            [39, 94,  0],
            [15, 59, 34]],
    
           [[25, 11, 43],
            [17, 46, 64],
            [59, 24, 13],
            [ 9, 15, 42],
            [46, 75, 65]],
    
           [[82, 52, 89],
            [71, 84, 14],
            [32, 65, 86],
            [ 1, 69, 76],
            [45, 20,  9]]])




```python
arr3[0][0][0]
```




    25



### 2. 切片
一维与列表完全一致
多维时同理


```python
arr1
```




    array([11, 81, 31, 59, 10, 56, 48, 36, 82, 19])




```python
arr1[0:3]
```




    array([11, 81, 31])




```python
arr1[::-1]
```




    array([19, 82, 36, 48, 56, 10, 59, 31, 81, 11])




```python
arr1[::2]
```




    array([11, 31, 10, 48, 82])




```python
arr2
```




    array([[46, 36, 77, 67, 25],
           [41, 76, 25, 48, 64],
           [58, 54, 81, 41,  6]])




```python
# 行切片
arr2[0:1]
```




    array([[46, 36, 77, 67, 25]])




```python
# 列切片
arr2[:,0:2]
```




    array([[46, 36],
           [41, 76],
           [58, 54]])




```python
arr2
```




    array([[46, 36, 77, 67, 25],
           [41, 76, 25, 48, 64],
           [58, 54, 81, 41,  6]])




```python
# 需求，将二维数组arr2进行行列逆向变换处理
arr2[::-1,:]
```




    array([[58, 54, 81, 41,  6],
           [41, 76, 25, 48, 64],
           [46, 36, 77, 67, 25]])




```python
arr2[:,::-1]
```




    array([[25, 67, 77, 36, 46],
           [64, 48, 25, 76, 41],
           [ 6, 41, 81, 54, 58]])




```python
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
# 注意：此处超纲，不要紧张
# 读取图片
sister = plt.imread('sister.jpg')
```


```python
sister.shape
```




    (300, 255, 3)




```python
plt.imshow(sister)
```




    <matplotlib.image.AxesImage at 0x24cd35fcf98>




![png](output_81_1.png)



```python
sister1 = sister[::-1]
```


```python
plt.imshow(sister1)
```




    <matplotlib.image.AxesImage at 0x24cd370cf28>




![png](output_83_1.png)



```python
sister2 = sister[:,::-1]
plt.imshow(sister2)
```




    <matplotlib.image.AxesImage at 0x24cd3544208>




![png](output_84_1.png)



```python
sister3 = sister[:,:,::-1]
plt.imshow(sister3)
```




    <matplotlib.image.AxesImage at 0x24cd3c33390>




![png](output_85_1.png)


将数据反转，例如[1,2,3]---->[3,2,1]

两个：：进行切片

### 3. 变形
使用reshape函数，注意参数是一个tuple！


```python
arr5 = np.random.random(size=25)
```


```python
arr5
```




    array([0.90804528, 0.30869937, 0.74985524, 0.54684972, 0.92053262,
           0.53912835, 0.54695453, 0.84884346, 0.65154233, 0.98041142,
           0.86042376, 0.36942207, 0.78283416, 0.34542292, 0.22834378,
           0.09784852, 0.10707408, 0.00434051, 0.85167701, 0.24166686,
           0.08241626, 0.729516  , 0.07928945, 0.67795173, 0.05147987])




```python
arr5.shape
```




    (25,)




```python
arr5.reshape((5,5))
```




    array([[0.90804528, 0.30869937, 0.74985524, 0.54684972, 0.92053262],
           [0.53912835, 0.54695453, 0.84884346, 0.65154233, 0.98041142],
           [0.86042376, 0.36942207, 0.78283416, 0.34542292, 0.22834378],
           [0.09784852, 0.10707408, 0.00434051, 0.85167701, 0.24166686],
           [0.08241626, 0.729516  , 0.07928945, 0.67795173, 0.05147987]])




```python
arr6 = arr5.reshape((25,1))
arr6
```




    array([[0.90804528],
           [0.30869937],
           [0.74985524],
           [0.54684972],
           [0.92053262],
           [0.53912835],
           [0.54695453],
           [0.84884346],
           [0.65154233],
           [0.98041142],
           [0.86042376],
           [0.36942207],
           [0.78283416],
           [0.34542292],
           [0.22834378],
           [0.09784852],
           [0.10707408],
           [0.00434051],
           [0.85167701],
           [0.24166686],
           [0.08241626],
           [0.729516  ],
           [0.07928945],
           [0.67795173],
           [0.05147987]])




```python
display(arr5.shape,arr6.shape)
```


    (25,)



    (25, 1)


-1 表示根据数组大小自动计算行数。


```python
arr7 = arr5.reshape(-1,1)
```


```python
arr7
```




    array([[0.90804528],
           [0.30869937],
           [0.74985524],
           [0.54684972],
           [0.92053262],
           [0.53912835],
           [0.54695453],
           [0.84884346],
           [0.65154233],
           [0.98041142],
           [0.86042376],
           [0.36942207],
           [0.78283416],
           [0.34542292],
           [0.22834378],
           [0.09784852],
           [0.10707408],
           [0.00434051],
           [0.85167701],
           [0.24166686],
           [0.08241626],
           [0.729516  ],
           [0.07928945],
           [0.67795173],
           [0.05147987]])




```python
arr8 = np.random.random(size=(5,5,3))
arr8
```




    array([[[0.4378124 , 0.86622411, 0.4514025 ],
            [0.20208716, 0.39066363, 0.81880838],
            [0.65304289, 0.70395026, 0.37192004],
            [0.02566805, 0.70963079, 0.04469499],
            [0.69951547, 0.54504744, 0.56235149]],
    
           [[0.1532418 , 0.0802895 , 0.80770669],
            [0.97583237, 0.18756185, 0.62407815],
            [0.13734561, 0.64034679, 0.07860697],
            [0.47930437, 0.6461185 , 0.25885189],
            [0.77657177, 0.62902119, 0.74812582]],
    
           [[0.09210895, 0.68729732, 0.87953284],
            [0.1213739 , 0.67701726, 0.87934454],
            [0.71747162, 0.3977164 , 0.75665751],
            [0.81382573, 0.31601279, 0.49267272],
            [0.96546174, 0.63272018, 0.26494927]],
    
           [[0.6404596 , 0.82405862, 0.41854037],
            [0.54052876, 0.28731239, 0.07270707],
            [0.09100632, 0.81935162, 0.13356481],
            [0.18376116, 0.80592834, 0.11226161],
            [0.84632946, 0.44263834, 0.97578643]],
    
           [[0.37315097, 0.75616857, 0.90959226],
            [0.5913203 , 0.40505837, 0.31871155],
            [0.09215261, 0.35348856, 0.29660107],
            [0.18349724, 0.18251386, 0.34683597],
            [0.29426166, 0.96583895, 0.08173155]]])




```python
# 变成一列
arr8.reshape(-1,1)
```




    array([[0.4378124 ],
           [0.86622411],
           [0.4514025 ],
           [0.20208716],
           [0.39066363],
           [0.81880838],
           [0.65304289],
           [0.70395026],
           [0.37192004],
           [0.02566805],
           [0.70963079],
           [0.04469499],
           [0.69951547],
           [0.54504744],
           [0.56235149],
           [0.1532418 ],
           [0.0802895 ],
           [0.80770669],
           [0.97583237],
           [0.18756185],
           [0.62407815],
           [0.13734561],
           [0.64034679],
           [0.07860697],
           [0.47930437],
           [0.6461185 ],
           [0.25885189],
           [0.77657177],
           [0.62902119],
           [0.74812582],
           [0.09210895],
           [0.68729732],
           [0.87953284],
           [0.1213739 ],
           [0.67701726],
           [0.87934454],
           [0.71747162],
           [0.3977164 ],
           [0.75665751],
           [0.81382573],
           [0.31601279],
           [0.49267272],
           [0.96546174],
           [0.63272018],
           [0.26494927],
           [0.6404596 ],
           [0.82405862],
           [0.41854037],
           [0.54052876],
           [0.28731239],
           [0.07270707],
           [0.09100632],
           [0.81935162],
           [0.13356481],
           [0.18376116],
           [0.80592834],
           [0.11226161],
           [0.84632946],
           [0.44263834],
           [0.97578643],
           [0.37315097],
           [0.75616857],
           [0.90959226],
           [0.5913203 ],
           [0.40505837],
           [0.31871155],
           [0.09215261],
           [0.35348856],
           [0.29660107],
           [0.18349724],
           [0.18251386],
           [0.34683597],
           [0.29426166],
           [0.96583895],
           [0.08173155]])




```python
# 变成一行
arr8.reshape(1,-1)
```




    array([[0.4378124 , 0.86622411, 0.4514025 , 0.20208716, 0.39066363,
            0.81880838, 0.65304289, 0.70395026, 0.37192004, 0.02566805,
            0.70963079, 0.04469499, 0.69951547, 0.54504744, 0.56235149,
            0.1532418 , 0.0802895 , 0.80770669, 0.97583237, 0.18756185,
            0.62407815, 0.13734561, 0.64034679, 0.07860697, 0.47930437,
            0.6461185 , 0.25885189, 0.77657177, 0.62902119, 0.74812582,
            0.09210895, 0.68729732, 0.87953284, 0.1213739 , 0.67701726,
            0.87934454, 0.71747162, 0.3977164 , 0.75665751, 0.81382573,
            0.31601279, 0.49267272, 0.96546174, 0.63272018, 0.26494927,
            0.6404596 , 0.82405862, 0.41854037, 0.54052876, 0.28731239,
            0.07270707, 0.09100632, 0.81935162, 0.13356481, 0.18376116,
            0.80592834, 0.11226161, 0.84632946, 0.44263834, 0.97578643,
            0.37315097, 0.75616857, 0.90959226, 0.5913203 , 0.40505837,
            0.31871155, 0.09215261, 0.35348856, 0.29660107, 0.18349724,
            0.18251386, 0.34683597, 0.29426166, 0.96583895, 0.08173155]])



### 4. 级联
1. np.concatenate()
级联需要注意的点：
- 级联的参数是列表：一定要加中括号或小括号
- 维度必须相同
- 形状相符
- 【重点】级联的方向默认是shape这个tuple的第一个值所代表的维度方向
- 可通过axis参数改变级联的方向


```python
n1 = np.ones(shape=(6,3))
n2 = np.zeros(shape=(6,3))
```


```python
display(n1,n2)
```


    array([[1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.]])



    array([[0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.]])



```python
np.concatenate?
```


    [1;31mDocstring:[0m
    concatenate((a1, a2, ...), axis=0, out=None)
    
    Join a sequence of arrays along an existing axis.
    
    Parameters
    ----------
    a1, a2, ... : sequence of array_like
        The arrays must have the same shape, except in the dimension
        corresponding to `axis` (the first, by default).
    axis : int, optional
        The axis along which the arrays will be joined.  If axis is None,
        arrays are flattened before use.  Default is 0.
    out : ndarray, optional
        If provided, the destination to place the result. The shape must be
        correct, matching that of what concatenate would have returned if no
        out argument were specified.
    
    Returns
    -------
    res : ndarray
        The concatenated array.
    
    See Also
    --------
    ma.concatenate : Concatenate function that preserves input masks.
    array_split : Split an array into multiple sub-arrays of equal or
                  near-equal size.
    split : Split array into a list of multiple sub-arrays of equal size.
    hsplit : Split array into multiple sub-arrays horizontally (column wise)
    vsplit : Split array into multiple sub-arrays vertically (row wise)
    dsplit : Split array into multiple sub-arrays along the 3rd axis (depth).
    stack : Stack a sequence of arrays along a new axis.
    hstack : Stack arrays in sequence horizontally (column wise)
    vstack : Stack arrays in sequence vertically (row wise)
    dstack : Stack arrays in sequence depth wise (along third dimension)
    
    Notes
    -----
    When one or more of the arrays to be concatenated is a MaskedArray,
    this function will return a MaskedArray object instead of an ndarray,
    but the input masks are *not* preserved. In cases where a MaskedArray
    is expected as input, use the ma.concatenate function from the masked
    array module instead.
    
    Examples
    --------
    >>> a = np.array([[1, 2], [3, 4]])
    >>> b = np.array([[5, 6]])
    >>> np.concatenate((a, b), axis=0)
    array([[1, 2],
           [3, 4],
           [5, 6]])
    >>> np.concatenate((a, b.T), axis=1)
    array([[1, 2, 5],
           [3, 4, 6]])
    >>> np.concatenate((a, b), axis=None)
    array([1, 2, 3, 4, 5, 6])
    
    This function will not preserve masking of MaskedArray inputs.
    
    >>> a = np.ma.arange(3)
    >>> a[1] = np.ma.masked
    >>> b = np.arange(2, 5)
    >>> a
    masked_array(data = [0 -- 2],
                 mask = [False  True False],
           fill_value = 999999)
    >>> b
    array([2, 3, 4])
    >>> np.concatenate([a, b])
    masked_array(data = [0 1 2 2 3 4],
                 mask = False,
           fill_value = 999999)
    >>> np.ma.concatenate([a, b])
    masked_array(data = [0 -- 2 2 3 4],
                 mask = [False  True False False False False],
           fill_value = 999999)
    [1;31mType:[0m      builtin_function_or_method
    



```python
# axis就表示维度的方向
np.concatenate((n1,n2),axis=1)
```




    array([[1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.]])



horizontal  
vertical

2. np.hstack与np.vstack  
水平级联与垂直级联,处理自己，进行维度的变更


```python
np.hstack((n1,n2))
```




    array([[1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.],
           [1., 1., 1., 0., 0., 0.]])




```python
np.vstack((n1,n2))
```




    array([[1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.],
           [0., 0., 0.]])



### 5. 切分

与级联类似，三个函数完成切分工作：
- np.split
- np.vsplit
- np.hsplit


```python
arr = np.random.randint(0,100,size=(6,6))
arr
```




    array([[85, 23, 92, 98, 83, 80],
           [42, 82, 77, 19, 91, 82],
           [61, 16, 23, 86,  1, 11],
           [61, 57, 44,  5, 10, 25],
           [24, 93,  0, 27, 35, 25],
           [50, 47, 61, 10, 48, 44]])




```python
np.split?
```


    [1;31mSignature:[0m [0mnp[0m[1;33m.[0m[0msplit[0m[1;33m([0m[0mary[0m[1;33m,[0m [0mindices_or_sections[0m[1;33m,[0m [0maxis[0m[1;33m=[0m[1;36m0[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Split an array into multiple sub-arrays.
    
    Parameters
    ----------
    ary : ndarray
        Array to be divided into sub-arrays.
    indices_or_sections : int or 1-D array
        If `indices_or_sections` is an integer, N, the array will be divided
        into N equal arrays along `axis`.  If such a split is not possible,
        an error is raised.
    
        If `indices_or_sections` is a 1-D array of sorted integers, the entries
        indicate where along `axis` the array is split.  For example,
        ``[2, 3]`` would, for ``axis=0``, result in
    
          - ary[:2]
          - ary[2:3]
          - ary[3:]
    
        If an index exceeds the dimension of the array along `axis`,
        an empty sub-array is returned correspondingly.
    axis : int, optional
        The axis along which to split, default is 0.
    
    Returns
    -------
    sub-arrays : list of ndarrays
        A list of sub-arrays.
    
    Raises
    ------
    ValueError
        If `indices_or_sections` is given as an integer, but
        a split does not result in equal division.
    
    See Also
    --------
    array_split : Split an array into multiple sub-arrays of equal or
                  near-equal size.  Does not raise an exception if
                  an equal division cannot be made.
    hsplit : Split array into multiple sub-arrays horizontally (column-wise).
    vsplit : Split array into multiple sub-arrays vertically (row wise).
    dsplit : Split array into multiple sub-arrays along the 3rd axis (depth).
    concatenate : Join a sequence of arrays along an existing axis.
    stack : Join a sequence of arrays along a new axis.
    hstack : Stack arrays in sequence horizontally (column wise).
    vstack : Stack arrays in sequence vertically (row wise).
    dstack : Stack arrays in sequence depth wise (along third dimension).
    
    Examples
    --------
    >>> x = np.arange(9.0)
    >>> np.split(x, 3)
    [array([ 0.,  1.,  2.]), array([ 3.,  4.,  5.]), array([ 6.,  7.,  8.])]
    
    >>> x = np.arange(8.0)
    >>> np.split(x, [3, 5, 6, 10])
    [array([ 0.,  1.,  2.]),
     array([ 3.,  4.]),
     array([ 5.]),
     array([ 6.,  7.]),
     array([], dtype=float64)]
    [1;31mFile:[0m      d:\software\anaconda3\lib\site-packages\numpy\lib\shape_base.py
    [1;31mType:[0m      function
    


在这个例子中，我们定义了一个一维数组 arr 包含整数 1 到 9。通过使用 np.split(arr, indices) 并传递索引数组 indices = [2, 5, 7]，我们将数组 arr 按照索引2、5和7进行分割，生成了四个子数组。然后，我们使用循环打印输出了每个子数组。

需要注意的是，传递的索引数组中的值应该是递增的，并且不超过数组的大小。这样才能确保正确的分割。如果索引数组中的值超出范围，将会引发 ValueError 异常。


```python
import numpy as np

arr10 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
indices = [2, 5, 7]

subarrays = np.split(arr10, indices)

for subarray in subarrays:
    print(subarray)
```

    [1 2]
    [3 4 5]
    [6 7]
    [8 9]
    


```python
# 指定切分的块数来进行切分，axis控制轴向
np.split(arr,indices_or_sections=3,axis=1)
```




    [array([[85, 23],
            [42, 82],
            [61, 16],
            [61, 57],
            [24, 93],
            [50, 47]]), array([[92, 98],
            [77, 19],
            [23, 86],
            [44,  5],
            [ 0, 27],
            [61, 10]]), array([[83, 80],
            [91, 82],
            [ 1, 11],
            [10, 25],
            [35, 25],
            [48, 44]])]




```python
np.arange(8)
```




    array([0, 1, 2, 3, 4, 5, 6, 7])




```python
# 自定义切分
# n m  切分范围为 0~n ,n~m, m~last
np.split(arr,indices_or_sections=[3,5],axis=1)
```




    [array([[85, 23, 92],
            [42, 82, 77],
            [61, 16, 23],
            [61, 57, 44],
            [24, 93,  0],
            [50, 47, 61]]), array([[98, 83],
            [19, 91],
            [86,  1],
            [ 5, 10],
            [27, 35],
            [10, 48]]), array([[80],
            [82],
            [11],
            [25],
            [25],
            [44]])]



### 6. 副本
所有赋值运算不会为ndarray的任何元素创建副本。对赋值后的对象的操作也对原来的对象生效。

可使用copy()函数创建副本


```python
arr = np.random.randint(0,10,10)
arr
```




    array([3, 3, 4, 3, 0, 4, 9, 3, 2, 5])




```python
arr[0] = 100
```


```python
arr
```




    array([100,   3,   4,   3,   0,   4,   9,   3,   2,   5])




```python
copy_arr = arr.copy()
```


```python
arr[0] = 10
arr
```




    array([10,  3,  4,  3,  0,  4,  9,  3,  2,  5])




```python
copy_arr
```




    array([100,   3,   4,   3,   0,   4,   9,   3,   2,   5])



## 四、ndarray的聚合操作

### 1. 求和np.sum


```python
n1 = np.arange(101)
```


```python
np.sum(n1)
```




    5050




```python
n2 = np.random.randint(0,10,size=(3,3))
```


```python
n2
```




    array([[9, 9, 8],
           [2, 3, 2],
           [8, 1, 1]])




```python
np.sum(n2,axis=None)
```




    43




```python
np.max(n2)
```




    9




```python
np.max(n2,axis=1)
```




    array([9, 3, 8])




```python
np.max(n2,axis=0)
```




    array([9, 9, 8])




```python
n2
```




    array([[9, 9, 8],
           [2, 3, 2],
           [8, 1, 1]])




```python
# 如果操作的是一维数组，没有问题，
# 如果是二维数组，要指定axis，不然得到的索引无法使用，需要对原数组做扁平化处理
np.argmin(n2,axis=1)
```




    array([2, 0, 1], dtype=int64)




```python
np.argmin(n2,axis=0)
```




    array([1, 2, 2], dtype=int64)



标准差是一组数据的离散程度的度量。它测量数据点与其均值之间的平均差异。标准差越大，数据越分散；标准差越小，数据越集中。


```python
np.std(n2)
```




    3.392075004994166




```python
import math

data = [9, 9, 8,2, 3, 2,8, 1, 1]

mean = sum(data) / len(data)  # 计算平均值

variance = sum((x - mean) ** 2 for x in data) / len(data)  # 计算方差

std_deviation = math.sqrt(variance)  # 计算标准差

print(std_deviation)
```

    3.3920750049941666
    


```python
n1 = np.array([1,False,3,True,5,6])
n1
```




    array([1, 0, 3, 1, 5, 6])




```python
np.all(n1)
```




    False



在这个例子中，我们定义了一个包含缺失值的数组 data，其中一项被设置为 np.nan。使用 np.isnan() 函数，我们可以检查数组中是否存在缺失值，并将结果存储在布尔数组 has_nan 中。接下来，我们使用 ~has_nan 来过滤掉缺失值，然后计算剩余数据的平均值，输出结果为 3.0。


```python
import numpy as np

data = np.array([1, 2, np.nan, 4, 5])

# 检查数组中是否存在缺失值
has_nan = np.isnan(data)
print(has_nan)  # 输出：[False False  True False False]

# 忽略缺失值计算数组的平均值
mean = np.mean(data[~has_nan])
print(mean)  # 输出：3.0
```

    [False False  True False False]
    3.0
    


```python
n2 = np.array([1,2,3,4,5.0])
n2[1] = np.nan
n2
```




    array([ 1., nan,  3.,  4.,  5.])




```python
np.all(n1)
```




    False




```python
# None python类型
# np.nan numpy的类型
type(None)
```




    NoneType




```python
type(np.nan)
```




    float




```python
arr = np.arange((100000),dtype=object)
```


```python
%timeit arr.sum()
```

    1.18 ms ± 19.4 µs per loop (mean ± std. dev. of 7 runs, 1000 loops each)
    


```python
arr1 = np.arange((100000),dtype=float)
```


```python
%timeit arr1.sum()
```

    21.3 µs ± 243 ns per loop (mean ± std. dev. of 7 runs, 10000 loops each)
    

### 2. 最大最小值：np.max/ np.min
同理

any()  有True返回True


all()  有False返回False


```python
n2 = np.array([np.nan,1,2,3,4])
n2.sum()
```




    nan




```python
# 处理包含空值的集合的聚合
np.nansum(n2)
```




    10.0



### 3. 其他聚合操作
    Function Name	NaN-safe Version	Description
    np.sum	np.nansum	Compute sum of elements
    np.prod	np.nanprod	Compute product of elements
    np.mean	np.nanmean	Compute mean of elements
    np.std	np.nanstd	Compute standard deviation
    np.var	np.nanvar	Compute variance
    np.min	np.nanmin	Find minimum value
    np.max	np.nanmax	Find maximum value
    np.argmin	np.nanargmin	Find index of minimum value
    np.argmax	np.nanargmax	Find index of maximum value
    np.median	np.nanmedian	Compute median of elements
    np.percentile	np.nanpercentile	Compute rank-based statistics of elements
    np.any	N/A	Evaluate whether any elements are true
    np.all	N/A	Evaluate whether all elements are true
    np.power 幂运算

np.sum 和 np.nansum 的区别
nan not a number

#### 操作文件

使用pandas打开文件president_heights.csv
获取文件中的数据

## 五、ndarray的矩阵操作

### 1. 基本矩阵操作

1) 算术运算符：
- 加减乘除


```python
n1 = np.random.randint(0,10,size=(3,3))
n2 = np.random.randint(0,10,size=(3,3))
display(n1,n2)
```


    array([[0, 5, 4],
           [8, 5, 1],
           [3, 4, 6]])



    array([[8, 5, 5],
           [0, 2, 5],
           [9, 2, 0]])



```python
n1 + n2
```




    array([[ 8, 10,  9],
           [ 8,  7,  6],
           [12,  6,  6]])




```python
# 注意：*符号只是两个矩阵对应位置的数据相乘
n1 * n2
```




    array([[ 0, 25, 20],
           [ 0, 10,  5],
           [27,  8,  0]])



2) 矩阵积np.dot()


```python
np.dot(n1,n2)
```




    array([[36, 18, 25],
           [73, 52, 65],
           [78, 35, 35]])



### 2. 广播机制

【重要】ndarray广播机制的两条规则
- 规则一：为缺失的维度补1
- 规则二：假定缺失元素用已有值填充


例1：
m = np.ones((2, 3))
a = np.arange(3)
求M+a


```python
m = np.ones((2,3))
a = np.array([5])
display(m,a)
```


    array([[1., 1., 1.],
           [1., 1., 1.]])



    array([5])



```python
m+a
```




    array([[6., 6., 6.],
           [6., 6., 6.]])



例2：
a = np.arange(3).reshape((3, 1))
b = np.arange(3)
求a+b


```python
a = np.arange(3).reshape((3, 1)) 
b = np.arange(3)
display(a,b)
a+b
```


    array([[0],
           [1],
           [2]])



    array([0, 1, 2])





    array([[0, 1, 2],
           [1, 2, 3],
           [2, 3, 4]])



习题
a = np.ones((4, 1))
b = np.arange(4)
求a+b


```python
a = np.ones((4, 1)) 
b = np.arange(4)
display(a,b)
a+b
```


    array([[1.],
           [1.],
           [1.],
           [1.]])



    array([0, 1, 2, 3])





    array([[1., 2., 3., 4.],
           [1., 2., 3., 4.],
           [1., 2., 3., 4.],
           [1., 2., 3., 4.]])



## 六、ndarray的排序

小测验：
使用以上所学numpy的知识，对一个ndarray对象进行冒泡排序。
def bubleSort(x):
代码越短越好

### 1. 快速排序
np.sort()与ndarray.sort()都可以，但有区别：
- np.sort()不改变输入
- ndarray.sort()本地处理，不占用空间，但改变输入


```python
arr = np.random.randint(0,100,size=10)
arr
```




    array([60, 37, 45, 66,  8, 75, 49, 53, 45, 91])




```python
sort_arr = np.sort(arr)
```


```python
sort_arr
```




    array([ 8, 37, 45, 45, 49, 53, 60, 66, 75, 91])




```python
arr.sort()
```


```python
arr
```




    array([ 8, 37, 45, 45, 49, 53, 60, 66, 75, 91])



### 2. 部分排序
np.partition(a,k)

有的时候我们不是对全部数据感兴趣，我们可能只对最小或最大的一部分感兴趣。
- 当k为正时，我们想要得到最小的k个数
- 当k为负时，我们想要得到最大的k个数


```python
arr = np.random.randint(0,100,size=10)
arr
```




    array([43, 75, 68, 72, 77, 76, 37, 48, 62, 76])




```python
np.partition(arr,2)
```




    array([37, 43, 48, 72, 77, 76, 75, 68, 62, 76])



np.partition(a, kth, axis=-1, kind='introselect', order=None) 函数的详细用法如下所述：

参数：

a：要进行分区操作的输入数组。
kth：指定分区的位置或索引。可以是整数，也可以是整数数组。如果是整数，则表示分区的位置（从小到大排序）。如果是整数数组，则根据数组的值来进行分区，小于等于 kth 的元素将位于左侧，大于 kth 的元素将位于右侧。
axis：指定在哪个轴上进行分区操作，默认值为 -1，表示最后一个轴。
kind：（可选参数）指定算法的类型，可以选择以下值：
'introselect'：默认选项，根据输入的大小选择合适的排序算法。对于大型数组，默认使用快速选择算法（Quickselect）。对于小型数组，默认使用堆排序（Heapsort）。
'heapsort'：使用堆排序算法。
'quicksort'：使用快速排序算法。
order：（可选参数）指定用于排序的字段，仅在 a 是结构化数组时有意义。
返回值：

分区后的数组，其中第 kth 个位置的元素及其左边的元素是整个数组中最小的 kth 个元素。
下面是一个例子，展示了 np.partition() 函数的详细用法：


```python
import numpy as np

# 二维数组示例
a = np.array([[3, 1, 4],
              [2, 5, 9]])

# 在最后一个轴上进行分区
partitioned = np.partition(a, 2, axis=-1)
print(partitioned)
# 输出：
# [[1 3 4]
#  [2 5 9]]

# 在第一个轴上进行分区
partitioned = np.partition(a, 1, axis=0)
print(partitioned)
# 输出：
# [[2 1 4]
#  [3 5 9]]

# 使用快速排序算法进行分区
partitioned = np.partition(a, 1, kind='introselect')
print(partitioned)
# 输出：
# [[2 1 4]
#  [3 5 9]]
```

    [[1 3 4]
     [2 5 9]]
    [[2 1 4]
     [3 5 9]]
    [[1 3 4]
     [2 5 9]]
    

这个例子中，我们使用了一个二维数组 a 进行分区操作。首先，我们在最后一个轴上进行分区，将每行的前两个最小元素放在左侧，其余元素放在右侧。然后，我们在第一个轴上进行分区，将每列的前一个最小元素放在顶部，其余元素放在底部。最后，我们使用快速排序算法进行分区，得到的结果与第一个分区的结果相同。

这只是 np.partition() 函数的一些用法示例，你可以根据具体的需求和数据结构进行适当的调整和应用。


```python

```

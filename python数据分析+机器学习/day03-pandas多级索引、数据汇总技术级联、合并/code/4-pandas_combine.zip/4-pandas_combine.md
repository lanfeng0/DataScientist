
# pandas的拼接操作

pandas的拼接分为两种：
- 级联：pd.concat, pd.append
- 合并：pd.merge, pd.join

## 0. 回顾numpy的级联


```python
import numpy as np
import pandas as pd
from pandas import Series,DataFrame
```


```python
n1 = np.random.random(size=(3,3))
print(n1)

n2 = np.random.random(size=(4,4))
print(n2)
np.concatenate((n1,n2),axis=1)
# np.concatenate((n1,n2),axis=1)
```

    [[0.33513933 0.8161296  0.94271746]
     [0.997328   0.14921713 0.43964555]
     [0.91123601 0.43022325 0.67303298]]
    [[0.55305819 0.17490522 0.07455062 0.54678101]
     [0.40758691 0.48606558 0.17907648 0.66114938]
     [0.95175315 0.0990287  0.27091342 0.41877985]
     [0.01760803 0.9046161  0.80450159 0.78503635]]
    


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-2-0bfd2ff87bc7> in <module>()
          4 n2 = np.random.random(size=(4,4))
          5 print(n2)
    ----> 6 np.concatenate((n1,n2),axis=1)
          7 # np.concatenate((n1,n2),axis=1)
    

    ValueError: all the input array dimensions except for the concatenation axis must match exactly



```python
a = np.array([[1, 2], [3, 4]])
b = np.array([[5,6]])
print(b.T)
np.concatenate((a, b.T), axis=1)
```

    [[5]
     [6]]
    




    array([[1, 2, 5],
           [3, 4, 6]])




```python
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
dancer = plt.imread('dancer.jpg')
plt.imshow(dancer)
```




    <matplotlib.image.AxesImage at 0x175894807f0>




![png](output_7_1.png)



```python
shishi = plt.imread('shishi.jpg')
plt.imshow(shishi)
```




    <matplotlib.image.AxesImage at 0x1758951cb38>




![png](output_8_1.png)



```python
dancer.shape
```




    (640, 480, 3)




```python
shishi.shape
```




    (300, 200, 3)




```python
dancer_shuai = dancer[100:400,100:300]
dancer_shuai.shape
```




    (300, 200, 3)




```python
plt.imshow(dancer_shuai)
```




    <matplotlib.image.AxesImage at 0x1758957bd30>




![png](output_12_1.png)



```python
image = np.concatenate((shishi,dancer_shuai),axis=1)
```


```python
plt.imshow(image)
```




    <matplotlib.image.AxesImage at 0x175895d46a0>




![png](output_14_1.png)


============================================

练习12：

1. 生成2个5*5的矩阵，对其分别进行两个维度上的级联

============================================

为方便讲解，我们首先定义一个生成DataFrame的函数：


```python
data={k:[k+str(i) for i in list('12345')] for k in list('ABCDE')}
display(data)
DataFrame(data=data,index=list('12345'))
```


    {'A': ['A1', 'A2', 'A3', 'A4', 'A5'],
     'B': ['B1', 'B2', 'B3', 'B4', 'B5'],
     'C': ['C1', 'C2', 'C3', 'C4', 'C5'],
     'D': ['D1', 'D2', 'D3', 'D4', 'D5'],
     'E': ['E1', 'E2', 'E3', 'E4', 'E5']}





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
    </tr>
  </tbody>
</table>
</div>




```python
def creat_DF(index,columns):
    data = {k:[k+str(i) for i in index] for k in columns}
    return DataFrame(data=data,index=index)
```


```python
df1 = creat_DF(list('12345'),list('ABCDE'))
```


```python
df2 = creat_DF(list('12345'),list('EFGHI'))
```


```python
pd.concat((df1,df2),axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>E</th>
      <th>F</th>
      <th>G</th>
      <th>H</th>
      <th>I</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
      <td>E1</td>
      <td>F1</td>
      <td>G1</td>
      <td>H1</td>
      <td>I1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
      <td>E2</td>
      <td>F2</td>
      <td>G2</td>
      <td>H2</td>
      <td>I2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
      <td>E3</td>
      <td>F3</td>
      <td>G3</td>
      <td>H3</td>
      <td>I3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
      <td>E4</td>
      <td>F4</td>
      <td>G4</td>
      <td>H4</td>
      <td>I4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
      <td>E5</td>
      <td>F5</td>
      <td>G5</td>
      <td>H5</td>
      <td>I5</td>
    </tr>
  </tbody>
</table>
</div>



## 1. 使用pd.concat()级联

pandas使用pd.concat函数，与np.concatenate函数类似，只是多了一些参数：
```
objs
axis=0
join='outer'
join_axes=None
ignore_index=False
```

### 1)  简单级联

和np.concatenate一样，优先增加行数（默认axis=0）

可以通过设置axis来改变级联方向

级连会把该方向上索引相同的元素放在一行（一列），index/columns在级联时可以重复

也可以选择忽略ignore_index，重新索引


```python
# 一般用于横向级联，也就是以行标签为参考进行的级联。ignore_index会重新分配标签，所以应保证你的标签是没有实际含义的
pd.concat((df1,df2),axis=0,ignore_index=True)
```

    D:\software\Anaconda3\lib\site-packages\ipykernel_launcher.py:2: FutureWarning: Sorting because non-concatenation axis is not aligned. A future version
    of pandas will change to not sort by default.
    
    To accept the future behavior, pass 'sort=False'.
    
    To retain the current behavior and silence the warning, pass 'sort=True'.
    
      
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>F</th>
      <th>G</th>
      <th>H</th>
      <th>I</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>E1</td>
      <td>F1</td>
      <td>G1</td>
      <td>H1</td>
      <td>I1</td>
    </tr>
    <tr>
      <th>6</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>E2</td>
      <td>F2</td>
      <td>G2</td>
      <td>H2</td>
      <td>I2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>E3</td>
      <td>F3</td>
      <td>G3</td>
      <td>H3</td>
      <td>I3</td>
    </tr>
    <tr>
      <th>8</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>E4</td>
      <td>F4</td>
      <td>G4</td>
      <td>H4</td>
      <td>I4</td>
    </tr>
    <tr>
      <th>9</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>E5</td>
      <td>F5</td>
      <td>G5</td>
      <td>H5</td>
      <td>I5</td>
    </tr>
  </tbody>
</table>
</div>



或者使用多层索引 keys  

concat([x,y],keys=['x','y'])


```python
pd.concat((df1,df2),axis=1,keys=['期中','期末'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="5" halign="left">期中</th>
      <th colspan="5" halign="left">期末</th>
    </tr>
    <tr>
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>E</th>
      <th>F</th>
      <th>G</th>
      <th>H</th>
      <th>I</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
      <td>E1</td>
      <td>F1</td>
      <td>G1</td>
      <td>H1</td>
      <td>I1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
      <td>E2</td>
      <td>F2</td>
      <td>G2</td>
      <td>H2</td>
      <td>I2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
      <td>E3</td>
      <td>F3</td>
      <td>G3</td>
      <td>H3</td>
      <td>I3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
      <td>E4</td>
      <td>F4</td>
      <td>G4</td>
      <td>H4</td>
      <td>I4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
      <td>E5</td>
      <td>F5</td>
      <td>G5</td>
      <td>H5</td>
      <td>I5</td>
    </tr>
  </tbody>
</table>
</div>




```python
df3 = creat_DF(list('123'),list('XYZ'))
df3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>X1</td>
      <td>Y1</td>
      <td>Z1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>X2</td>
      <td>Y2</td>
      <td>Z2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>X3</td>
      <td>Y3</td>
      <td>Z3</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
    </tr>
  </tbody>
</table>
</div>




```python
total = pd.concat((df1,df3),axis=1)
```

    D:\software\Anaconda3\lib\site-packages\ipykernel_launcher.py:1: FutureWarning: Sorting because non-concatenation axis is not aligned. A future version
    of pandas will change to not sort by default.
    
    To accept the future behavior, pass 'sort=False'.
    
    To retain the current behavior and silence the warning, pass 'sort=True'.
    
      """Entry point for launching an IPython kernel.
    


```python
# total.fillna(value=0)
total
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>X</th>
      <th>Y</th>
      <th>Z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
      <td>X1</td>
      <td>Y1</td>
      <td>Z1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
      <td>X2</td>
      <td>Y2</td>
      <td>Z2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
      <td>X3</td>
      <td>Y3</td>
      <td>Z3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 【重点】
# 查看一张表哪一列\行存在空值
print(total.isnull())
nan_list = total.isnull().any(axis=0)
```

           A      B      C      D      E      X      Y      Z
    1  False  False  False  False  False  False  False  False
    2  False  False  False  False  False  False  False  False
    3  False  False  False  False  False  False  False  False
    4  False  False  False  False  False   True   True   True
    5  False  False  False  False  False   True   True   True
    


```python
nan_list
```




    A    False
    B    False
    C    False
    D    False
    E    False
    X     True
    Y     True
    Z     True
    dtype: bool




```python
total.loc[:,nan_list]
#: 表示选择所有行，而 nan_list 表示选择列表中列标签对应的列。这将返回一个新的 DataFrame，其中包含所有行和指定列的数据。
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>X1</td>
      <td>Y1</td>
      <td>Z1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>X2</td>
      <td>Y2</td>
      <td>Z2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>X3</td>
      <td>Y3</td>
      <td>Z3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 需求:提取包含空值的列
```


```python
n = np.array([True,False,True])
n.any()
```




    True




```python
n1 = np.array([1,2,3,4,5,6])
bool_list = [True,False,False,True,False,True]
n1[bool_list]
```




    array([1, 4, 6])



============================================

练习13：

1. 想一想级联的应用场景？

2. 使用昨天的知识，建立一个期中考试张三、李四的成绩表ddd

3. 假设新增考试学科"计算机"，如何实现？

4. 新增王老五同学的成绩，如何实现？

============================================


```python
data = np.random.randint(0,150,size=(2,3))
index = ['张三','李四']
columns = ['python','Java','C']
df = DataFrame(data=data,index=index,columns=columns)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>python</th>
      <th>Java</th>
      <th>C</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>张三</th>
      <td>27</td>
      <td>72</td>
      <td>54</td>
    </tr>
    <tr>
      <th>李四</th>
      <td>57</td>
      <td>125</td>
      <td>73</td>
    </tr>
  </tbody>
</table>
</div>




```python
data1 = np.random.randint(0,150,size=(2,1))
index1 =  ['张三','李四']
columns1 = ['计算机']
df2 = DataFrame(data=data1,index=index1,columns=columns1)
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>计算机</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>张三</th>
      <td>134</td>
    </tr>
    <tr>
      <th>李四</th>
      <td>89</td>
    </tr>
  </tbody>
</table>
</div>




```python
score = pd.concat((df,df2),axis=1)
```


```python
score
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>python</th>
      <th>Java</th>
      <th>C</th>
      <th>计算机</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>张三</th>
      <td>27</td>
      <td>72</td>
      <td>54</td>
      <td>134</td>
    </tr>
    <tr>
      <th>李四</th>
      <td>57</td>
      <td>125</td>
      <td>73</td>
      <td>89</td>
    </tr>
  </tbody>
</table>
</div>




```python
columns2 = score.columns
data2 = np.random.randint(0,150,size=(1,4))
index2 = ['王老五']
df3 = DataFrame(data=data2,index=index2,columns=columns2)
df3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>python</th>
      <th>Java</th>
      <th>C</th>
      <th>计算机</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>王老五</th>
      <td>146</td>
      <td>25</td>
      <td>111</td>
      <td>128</td>
    </tr>
  </tbody>
</table>
</div>




```python
score.append(df3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>python</th>
      <th>Java</th>
      <th>C</th>
      <th>计算机</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>张三</th>
      <td>27</td>
      <td>72</td>
      <td>54</td>
      <td>134</td>
    </tr>
    <tr>
      <th>李四</th>
      <td>57</td>
      <td>125</td>
      <td>73</td>
      <td>89</td>
    </tr>
    <tr>
      <th>王老五</th>
      <td>146</td>
      <td>25</td>
      <td>111</td>
      <td>128</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.concat((score,df3))
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>python</th>
      <th>Java</th>
      <th>C</th>
      <th>计算机</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>张三</th>
      <td>27</td>
      <td>72</td>
      <td>54</td>
      <td>134</td>
    </tr>
    <tr>
      <th>李四</th>
      <td>57</td>
      <td>125</td>
      <td>73</td>
      <td>89</td>
    </tr>
    <tr>
      <th>王老五</th>
      <td>146</td>
      <td>25</td>
      <td>111</td>
      <td>128</td>
    </tr>
  </tbody>
</table>
</div>



### 2) 不匹配级联

不匹配指的是级联的维度的索引不一致。例如纵向级联时列索引不一致，横向级联时行索引不一致

有3种连接方式：

- 外连接：补NaN（默认模式）

- 内连接：只连接匹配的项

- 连接指定轴 join_axes


```python
df1 = creat_DF(list('12345'),list('ABCDE'))
print(df1)

df2 = creat_DF(list('234'),list('CDE'))
print(df2)
pd.concat((df1,df2),axis=1,join='inner')
```

        A   B   C   D   E
    1  A1  B1  C1  D1  E1
    2  A2  B2  C2  D2  E2
    3  A3  B3  C3  D3  E3
    4  A4  B4  C4  D4  E4
    5  A5  B5  C5  D5  E5
        C   D   E
    2  C2  D2  E2
    3  C3  D3  E3
    4  C4  D4  E4
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(df1)

print(df2)
display(pd.concat((df1,df2),axis=0))
pd.concat((df1,df2),axis=0,join_axes=[df2.columns])
```

        A   B   C   D   E
    1  A1  B1  C1  D1  E1
    2  A2  B2  C2  D2  E2
    3  A3  B3  C3  D3  E3
    4  A4  B4  C4  D4  E4
    5  A5  B5  C5  D5  E5
        C   D   E
    2  C2  D2  E2
    3  C3  D3  E3
    4  C4  D4  E4
    

    D:\software\Anaconda3\lib\site-packages\ipykernel_launcher.py:4: FutureWarning: Sorting because non-concatenation axis is not aligned. A future version
    of pandas will change to not sort by default.
    
    To accept the future behavior, pass 'sort=False'.
    
    To retain the current behavior and silence the warning, pass 'sort=True'.
    
      after removing the cwd from sys.path.
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
  </tbody>
</table>
</div>


    D:\software\Anaconda3\lib\site-packages\ipykernel_launcher.py:5: FutureWarning: Sorting because non-concatenation axis is not aligned. A future version
    of pandas will change to not sort by default.
    
    To accept the future behavior, pass 'sort=False'.
    
    To retain the current behavior and silence the warning, pass 'sort=True'.
    
      """
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A1</td>
      <td>B1</td>
      <td>C1</td>
      <td>D1</td>
      <td>E1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2</td>
      <td>B2</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A3</td>
      <td>B3</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A4</td>
      <td>B4</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A5</td>
      <td>B5</td>
      <td>C5</td>
      <td>D5</td>
      <td>E5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>C2</td>
      <td>D2</td>
      <td>E2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>C3</td>
      <td>D3</td>
      <td>E3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>C4</td>
      <td>D4</td>
      <td>E4</td>
    </tr>
  </tbody>
</table>
</div>




```python
index = pd.Index(['C','D'])
print(index)
```

    Index(['C', 'D'], dtype='object')
    


```python
index
```




    Index(['C', 'D'], dtype='object')




```python
pd.concat((df1,df2),axis=0,join_axes=[index])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>C1</td>
      <td>D1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>C2</td>
      <td>D2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>C3</td>
      <td>D3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>C4</td>
      <td>D4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>C5</td>
      <td>D5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>C2</td>
      <td>D2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>C3</td>
      <td>D3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>C4</td>
      <td>D4</td>
    </tr>
  </tbody>
</table>
</div>




```python
type(df2.columns)
```




    pandas.core.indexes.base.Index




```python
pd.core.indexes.base.Index?
```


    [1;31mInit signature:[0m [0mpd[0m[1;33m.[0m[0mcore[0m[1;33m.[0m[0mindexes[0m[1;33m.[0m[0mbase[0m[1;33m.[0m[0mIndex[0m[1;33m([0m[0mdata[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mdtype[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mcopy[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0mname[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mfastpath[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0mtupleize_cols[0m[1;33m=[0m[1;32mTrue[0m[1;33m,[0m [1;33m**[0m[0mkwargs[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m     
    Immutable ndarray implementing an ordered, sliceable set. The basic object
    storing axis labels for all pandas objects
    
    Parameters
    ----------
    data : array-like (1-dimensional)
    dtype : NumPy dtype (default: object)
        If dtype is None, we find the dtype that best fits the data.
        If an actual dtype is provided, we coerce to that dtype if it's safe.
        Otherwise, an error will be raised.
    copy : bool
        Make a copy of input ndarray
    name : object
        Name to be stored in the index
    tupleize_cols : bool (default: True)
        When True, attempt to create a MultiIndex if possible
    
    Notes
    -----
    An Index instance can **only** contain hashable objects
    
    Examples
    --------
    >>> pd.Index([1, 2, 3])
    Int64Index([1, 2, 3], dtype='int64')
    
    >>> pd.Index(list('abc'))
    Index(['a', 'b', 'c'], dtype='object')
    
    See Also
    ---------
    RangeIndex : Index implementing a monotonic integer range
    CategoricalIndex : Index of :class:`Categorical` s.
    MultiIndex : A multi-level, or hierarchical, Index
    IntervalIndex : an Index of :class:`Interval` s.
    DatetimeIndex, TimedeltaIndex, PeriodIndex
    Int64Index, UInt64Index,  Float64Index
    [1;31mFile:[0m           d:\software\anaconda3\lib\site-packages\pandas\core\indexes\base.py
    [1;31mType:[0m           type
    


============================================

练习14：

    假设【期末】考试ddd2的成绩没有张三的，只有李四、王老五、赵小六的，使用多种方法级联

============================================

### 3) 使用append()函数添加

由于在后面级联的使用非常普遍，因此有一个函数append专门用于在后面添加

注意:append函数只是沿着axis=0的方向进行级联

============================================

练习15：

    新建一个只有张三李四王老五的期末考试成绩单ddd3，使用append()与期中考试成绩表ddd级联

============================================

## 2. 使用pd.merge()合并


```python
# 读取文件（conda install openpyxl）
# 第一个参数：读取的excel文件的路径
# 第二个参数：sheet_name = 0\1\2\3  第一个sheet就是0
# table1 = pd.read_excel('关系表.xlsx',sheet_name=1)
table1 = pd.read_excel('关系表.xls', sheet_name=1)

display(table1)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>参考价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000</td>
    </tr>
  </tbody>
</table>
</div>



```python
table2 = pd.read_excel('关系表.xls',sheet_name=2)
table3 = pd.read_excel('关系表.xls',sheet_name=3)
table4 = pd.read_excel('关系表.xls',sheet_name=4)
```


```python
display(table1,table2,table3,table4)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>参考价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>重量</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>0.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>other</td>
      <td>0.60</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区</th>
      <th>手机型号</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>2</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>3</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>发货地区</th>
      <th>手机型号</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>beijing</td>
      <td>iPhone</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>beijing</td>
      <td>windowsPhone</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>2</th>
      <td>beijing</td>
      <td>Android</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>3</th>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>4</th>
      <td>guangzhou</td>
      <td>windowsPhone</td>
      <td>2800</td>
    </tr>
    <tr>
      <th>5</th>
      <td>guangzhou</td>
      <td>Android</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>6</th>
      <td>shenzhen</td>
      <td>iPhone</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>7</th>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>2750</td>
    </tr>
    <tr>
      <th>8</th>
      <td>shenzhen</td>
      <td>Android</td>
      <td>3900</td>
    </tr>
  </tbody>
</table>
</div>


merge与concat的区别在于，merge需要依据某一共同列来进行合并

使用pd.merge()合并时，会自动根据两者相同column名称的那一列，作为key来进行合并。

注意每一列元素的顺序不要求一致

###  1) 一对一合并


```python
pd.merge(table1,table2,how='outer')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>参考价格</th>
      <th>重量</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500.0</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500.0</td>
      <td>0.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000.0</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>other</td>
      <td>NaN</td>
      <td>0.60</td>
    </tr>
  </tbody>
</table>
</div>



### 2) 多对一合并


```python
pd.merge(table1,table3,how='outer')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>参考价格</th>
      <th>经销商</th>
      <th>发货地区</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500</td>
      <td>petter</td>
      <td>shenzhen</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500</td>
      <td>dancer</td>
      <td>beijing</td>
    </tr>
    <tr>
      <th>2</th>
      <td>iPhone</td>
      <td>7500</td>
      <td>tom</td>
      <td>guangzhou</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Android</td>
      <td>4000</td>
      <td>lucy</td>
      <td>beijing</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Android</td>
      <td>4000</td>
      <td>mery</td>
      <td>guangzhou</td>
    </tr>
  </tbody>
</table>
</div>



### 3) 多对多合并


```python
table3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区</th>
      <th>手机型号</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>2</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>3</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
    </tr>
  </tbody>
</table>
</div>




```python
table4
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>发货地区</th>
      <th>手机型号</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>beijing</td>
      <td>iPhone</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>beijing</td>
      <td>windowsPhone</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>2</th>
      <td>beijing</td>
      <td>Android</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>3</th>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>4</th>
      <td>guangzhou</td>
      <td>windowsPhone</td>
      <td>2800</td>
    </tr>
    <tr>
      <th>5</th>
      <td>guangzhou</td>
      <td>Android</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>6</th>
      <td>shenzhen</td>
      <td>iPhone</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>7</th>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>2750</td>
    </tr>
    <tr>
      <th>8</th>
      <td>shenzhen</td>
      <td>Android</td>
      <td>3900</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.merge(table3,table4,how='outer')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区</th>
      <th>手机型号</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>2</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>3</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>2750</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>beijing</td>
      <td>windowsPhone</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>6</th>
      <td>NaN</td>
      <td>guangzhou</td>
      <td>windowsPhone</td>
      <td>2800</td>
    </tr>
    <tr>
      <th>7</th>
      <td>NaN</td>
      <td>shenzhen</td>
      <td>iPhone</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>8</th>
      <td>NaN</td>
      <td>shenzhen</td>
      <td>Android</td>
      <td>3900</td>
    </tr>
  </tbody>
</table>
</div>



### 4) key的规范化

- 使用on=显式指定哪一列为key,当有多个key相同时使用


```python
pd.merge?
```


    [1;31mSignature:[0m [0mpd[0m[1;33m.[0m[0mmerge[0m[1;33m([0m[0mleft[0m[1;33m,[0m [0mright[0m[1;33m,[0m [0mhow[0m[1;33m=[0m[1;34m'inner'[0m[1;33m,[0m [0mon[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mleft_on[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mright_on[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m [0mleft_index[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0mright_index[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0msort[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0msuffixes[0m[1;33m=[0m[1;33m([0m[1;34m'_x'[0m[1;33m,[0m [1;34m'_y'[0m[1;33m)[0m[1;33m,[0m [0mcopy[0m[1;33m=[0m[1;32mTrue[0m[1;33m,[0m [0mindicator[0m[1;33m=[0m[1;32mFalse[0m[1;33m,[0m [0mvalidate[0m[1;33m=[0m[1;32mNone[0m[1;33m)[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Merge DataFrame objects by performing a database-style join operation by
    columns or indexes.
    
    If joining columns on columns, the DataFrame indexes *will be
    ignored*. Otherwise if joining indexes on indexes or indexes on a column or
    columns, the index will be passed on.
    
    Parameters
    ----------
    left : DataFrame
    right : DataFrame
    how : {'left', 'right', 'outer', 'inner'}, default 'inner'
        * left: use only keys from left frame, similar to a SQL left outer join;
          preserve key order
        * right: use only keys from right frame, similar to a SQL right outer join;
          preserve key order
        * outer: use union of keys from both frames, similar to a SQL full outer
          join; sort keys lexicographically
        * inner: use intersection of keys from both frames, similar to a SQL inner
          join; preserve the order of the left keys
    on : label or list
        Column or index level names to join on. These must be found in both
        DataFrames. If `on` is None and not merging on indexes then this defaults
        to the intersection of the columns in both DataFrames.
    left_on : label or list, or array-like
        Column or index level names to join on in the left DataFrame. Can also
        be an array or list of arrays of the length of the left DataFrame.
        These arrays are treated as if they are columns.
    right_on : label or list, or array-like
        Column or index level names to join on in the right DataFrame. Can also
        be an array or list of arrays of the length of the right DataFrame.
        These arrays are treated as if they are columns.
    left_index : boolean, default False
        Use the index from the left DataFrame as the join key(s). If it is a
        MultiIndex, the number of keys in the other DataFrame (either the index
        or a number of columns) must match the number of levels
    right_index : boolean, default False
        Use the index from the right DataFrame as the join key. Same caveats as
        left_index
    sort : boolean, default False
        Sort the join keys lexicographically in the result DataFrame. If False,
        the order of the join keys depends on the join type (how keyword)
    suffixes : 2-length sequence (tuple, list, ...)
        Suffix to apply to overlapping column names in the left and right
        side, respectively
    copy : boolean, default True
        If False, do not copy data unnecessarily
    indicator : boolean or string, default False
        If True, adds a column to output DataFrame called "_merge" with
        information on the source of each row.
        If string, column with information on source of each row will be added to
        output DataFrame, and column will be named value of string.
        Information column is Categorical-type and takes on a value of "left_only"
        for observations whose merge key only appears in 'left' DataFrame,
        "right_only" for observations whose merge key only appears in 'right'
        DataFrame, and "both" if the observation's merge key is found in both.
    
    validate : string, default None
        If specified, checks if merge is of specified type.
    
        * "one_to_one" or "1:1": check if merge keys are unique in both
          left and right datasets.
        * "one_to_many" or "1:m": check if merge keys are unique in left
          dataset.
        * "many_to_one" or "m:1": check if merge keys are unique in right
          dataset.
        * "many_to_many" or "m:m": allowed, but does not result in checks.
    
        .. versionadded:: 0.21.0
    
    Notes
    -----
    Support for specifying index levels as the `on`, `left_on`, and
    `right_on` parameters was added in version 0.23.0
    
    Examples
    --------
    
    >>> A              >>> B
        lkey value         rkey value
    0   foo  1         0   foo  5
    1   bar  2         1   bar  6
    2   baz  3         2   qux  7
    3   foo  4         3   bar  8
    
    >>> A.merge(B, left_on='lkey', right_on='rkey', how='outer')
       lkey  value_x  rkey  value_y
    0  foo   1        foo   5
    1  foo   4        foo   5
    2  bar   2        bar   6
    3  bar   2        bar   8
    4  baz   3        NaN   NaN
    5  NaN   NaN      qux   7
    
    Returns
    -------
    merged : DataFrame
        The output type will the be same as 'left', if it is a subclass
        of DataFrame.
    
    See also
    --------
    merge_ordered
    merge_asof
    DataFrame.join
    [1;31mFile:[0m      d:\software\anaconda3\lib\site-packages\pandas\core\reshape\merge.py
    [1;31mType:[0m      function
    



```python
df1 = DataFrame({'employee':['Jack',"Summer","Steve"],
                 'group':['Accounting','Finance','Marketing']})

df2 = DataFrame({'employee':['Jack','Bob',"Jake"],
                 'hire_date':[2003,2009,2012],
                'group':['Accounting','sell','ceo']})
display(df1,df2,pd.merge(df1,df2,how='inner'),pd.merge(df1,df2,on = 'employee',how='outer'))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>employee</th>
      <th>group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Jack</td>
      <td>Accounting</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Summer</td>
      <td>Finance</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Steve</td>
      <td>Marketing</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>employee</th>
      <th>hire_date</th>
      <th>group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Jack</td>
      <td>2003</td>
      <td>Accounting</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bob</td>
      <td>2009</td>
      <td>sell</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Jake</td>
      <td>2012</td>
      <td>ceo</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>employee</th>
      <th>group</th>
      <th>hire_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Jack</td>
      <td>Accounting</td>
      <td>2003</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>employee</th>
      <th>group_x</th>
      <th>hire_date</th>
      <th>group_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Jack</td>
      <td>Accounting</td>
      <td>2003.0</td>
      <td>Accounting</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Summer</td>
      <td>Finance</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Steve</td>
      <td>Marketing</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bob</td>
      <td>NaN</td>
      <td>2009.0</td>
      <td>sell</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Jake</td>
      <td>NaN</td>
      <td>2012.0</td>
      <td>ceo</td>
    </tr>
  </tbody>
</table>
</div>



```python
pd.merge(table3,table4,on='手机型号')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区_x</th>
      <th>手机型号</th>
      <th>发货地区_y</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>beijing</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>guangzhou</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>2</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>shenzhen</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>3</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>beijing</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>guangzhou</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>5</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>shenzhen</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>6</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>beijing</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>7</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>guangzhou</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>8</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>shenzhen</td>
      <td>3900</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>beijing</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>guangzhou</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>11</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>shenzhen</td>
      <td>3900</td>
    </tr>
    <tr>
      <th>12</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>beijing</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>13</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>guangzhou</td>
      <td>2800</td>
    </tr>
    <tr>
      <th>14</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>shenzhen</td>
      <td>2750</td>
    </tr>
  </tbody>
</table>
</div>



- 使用left_on和right_on指定左右两边的列作为key，当左右两边的key都不想等时使用


```python
table1.columns = ['型号','参考价格']
table1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>型号</th>
      <th>参考价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000</td>
    </tr>
  </tbody>
</table>
</div>




```python
table2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>重量</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>0.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>other</td>
      <td>0.60</td>
    </tr>
  </tbody>
</table>
</div>




```python
table = pd.merge(table1,table2,left_on='型号',right_on='手机型号',how='outer')
print(table)
```

                 型号    参考价格          手机型号    重量
    0  windowsPhone  2500.0  windowsPhone  0.50
    1        iPhone  7500.0        iPhone  0.40
    2       Android  4000.0       Android  0.45
    3           NaN     NaN         other  0.60
    


```python
# 删除一行或一列
# 参数1：要删除的行、列标签名
# 参数2：axis 指定删除的方向，必须与标签名匹配方向
table.drop('手机型号',axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>型号</th>
      <th>参考价格</th>
      <th>重量</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500.0</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500.0</td>
      <td>0.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000.0</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.60</td>
    </tr>
  </tbody>
</table>
</div>



============================================

练习16：

1. 假设有两份成绩单，除了ddd是张三李四王老五之外，还有ddd4是张三和赵小六的成绩单，如何合并？

2. 如果ddd4中张三的名字被打错了，成为了张十三，怎么办？

3. 自行练习多对一，多对多的情况  

4. 自学left_index,right_index

============================================

### 5) 内合并与外合并

- 内合并：只保留两者都有的key（默认模式）

- 外合并 how='outer'：补NaN

- 左合并、右合并：how='left'，how='right'，


```python
table1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>型号</th>
      <th>参考价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000</td>
    </tr>
  </tbody>
</table>
</div>




```python
table2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>手机型号</th>
      <th>重量</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>0.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>other</td>
      <td>0.60</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.merge(table1,table2,left_on='型号',right_on='手机型号',how='right')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>型号</th>
      <th>参考价格</th>
      <th>手机型号</th>
      <th>重量</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>windowsPhone</td>
      <td>2500.0</td>
      <td>windowsPhone</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>7500.0</td>
      <td>iPhone</td>
      <td>0.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>4000.0</td>
      <td>Android</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>other</td>
      <td>0.60</td>
    </tr>
  </tbody>
</table>
</div>



============================================

练习17：



1. 考虑应用情景，使用多种方式合并ddd与ddd4

============================================

### 6) 列冲突的解决

当列冲突时，即有多个列名称相同时，需要使用on=来指定哪一个列作为key，配合suffixes指定冲突列名

可以使用suffixes=自己指定后缀


```python
table3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区</th>
      <th>手机型号</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>2</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>3</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
    </tr>
  </tbody>
</table>
</div>




```python
table4
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>发货地区</th>
      <th>手机型号</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>beijing</td>
      <td>iPhone</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>beijing</td>
      <td>windowsPhone</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>2</th>
      <td>beijing</td>
      <td>Android</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>3</th>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>4</th>
      <td>guangzhou</td>
      <td>windowsPhone</td>
      <td>2800</td>
    </tr>
    <tr>
      <th>5</th>
      <td>guangzhou</td>
      <td>Android</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>6</th>
      <td>shenzhen</td>
      <td>iPhone</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>7</th>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>2750</td>
    </tr>
    <tr>
      <th>8</th>
      <td>shenzhen</td>
      <td>Android</td>
      <td>3900</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.merge(table3,table4,on='手机型号',suffixes=['_上半年','_下半年'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区_上半年</th>
      <th>手机型号</th>
      <th>发货地区_下半年</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>beijing</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>guangzhou</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>2</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>shenzhen</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>3</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>beijing</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>guangzhou</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>5</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>shenzhen</td>
      <td>7400</td>
    </tr>
    <tr>
      <th>6</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>beijing</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>7</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>guangzhou</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>8</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>shenzhen</td>
      <td>3900</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>beijing</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>guangzhou</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>11</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>shenzhen</td>
      <td>3900</td>
    </tr>
    <tr>
      <th>12</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>beijing</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>13</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>guangzhou</td>
      <td>2800</td>
    </tr>
    <tr>
      <th>14</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>shenzhen</td>
      <td>2750</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 如果你有更多的列是相同的，而只希望根据其中某几列来合并
pd.merge(table3,table4,on=['发货地区','手机型号'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>经销商</th>
      <th>发货地区</th>
      <th>手机型号</th>
      <th>价格</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>dancer</td>
      <td>beijing</td>
      <td>iPhone</td>
      <td>7000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lucy</td>
      <td>beijing</td>
      <td>Android</td>
      <td>3600</td>
    </tr>
    <tr>
      <th>2</th>
      <td>tom</td>
      <td>guangzhou</td>
      <td>iPhone</td>
      <td>7600</td>
    </tr>
    <tr>
      <th>3</th>
      <td>petter</td>
      <td>shenzhen</td>
      <td>windowsPhone</td>
      <td>2750</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mery</td>
      <td>guangzhou</td>
      <td>Android</td>
      <td>4200</td>
    </tr>
  </tbody>
</table>
</div>



============================================

练习18：

    假设有两个同学都叫李四，ddd5、ddd6都是张三和李四的成绩表，如何合并？

============================================

## 作业
## 3. 案例分析：美国各州人口数据分析

作业知识补充


```python
# unique() 去重函数
s = Series(['Tom','Lucy','Tom','dancer','Lucy'])
```


```python
s.unique()
```




    array(['Tom', 'Lucy', 'dancer'], dtype=object)




```python
n = DataFrame({'name':['Tom','Lucy','Tom','dancer','Lucy'],'age':[12,13,12,11,15]})
n
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Tom</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Lucy</td>
      <td>13</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Tom</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>dancer</td>
      <td>11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lucy</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>




```python
# query 条件查询函数
n.query("name == 'Lucy' & age>14")  
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>Lucy</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>



首先导入文件，并查看数据样本


```python
import numpy as np
import pandas as pd
from pandas import Series,DataFrame
```


```python
s_abb = pd.read_csv('../data/state-abbrevs.csv')
s_abb.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>abbreviation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alabama</td>
      <td>AL</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alaska</td>
      <td>AK</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Arizona</td>
      <td>AZ</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Arkansas</td>
      <td>AR</td>
    </tr>
    <tr>
      <th>4</th>
      <td>California</td>
      <td>CA</td>
    </tr>
  </tbody>
</table>
</div>




```python
s_pop = pd.read_csv('../data/state-population.csv')
s_pop.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state/region</th>
      <th>ages</th>
      <th>year</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>AL</td>
      <td>under18</td>
      <td>2012</td>
      <td>1117489.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>AL</td>
      <td>total</td>
      <td>2012</td>
      <td>4817528.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AL</td>
      <td>under18</td>
      <td>2010</td>
      <td>1130966.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>AL</td>
      <td>total</td>
      <td>2010</td>
      <td>4785570.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AL</td>
      <td>under18</td>
      <td>2011</td>
      <td>1125763.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
s_ares = pd.read_csv('../data/state-areas.csv')
s_ares.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>area (sq. mi)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alabama</td>
      <td>52423</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alaska</td>
      <td>656425</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Arizona</td>
      <td>114006</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Arkansas</td>
      <td>53182</td>
    </tr>
    <tr>
      <th>4</th>
      <td>California</td>
      <td>163707</td>
    </tr>
  </tbody>
</table>
</div>



合并pop与abbrevs两个DataFrame，分别依据state/region列和abbreviation列来合并。

为了保留所有信息，使用外合并。


```python
abb_pop = pd.merge(s_abb,s_pop,how='outer',
                   left_on = 'abbreviation',right_on='state/region')
```


```python
abb_pop.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>abbreviation</th>
      <th>state/region</th>
      <th>ages</th>
      <th>year</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>AL</td>
      <td>under18</td>
      <td>2012</td>
      <td>1117489.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>AL</td>
      <td>total</td>
      <td>2012</td>
      <td>4817528.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 删除一列
abb_pop = abb_pop.drop('abbreviation',axis=1)
```


```python
abb_pop
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>state/region</th>
      <th>ages</th>
      <th>year</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2012</td>
      <td>1117489.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2012</td>
      <td>4817528.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2010</td>
      <td>1130966.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2010</td>
      <td>4785570.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2011</td>
      <td>1125763.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2011</td>
      <td>4801627.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2009</td>
      <td>4757938.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2009</td>
      <td>1134192.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2013</td>
      <td>1111481.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2013</td>
      <td>4833722.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2007</td>
      <td>4672840.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2007</td>
      <td>1132296.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2008</td>
      <td>4718206.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2008</td>
      <td>1134927.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2005</td>
      <td>4569805.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2005</td>
      <td>1117229.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2006</td>
      <td>4628981.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2006</td>
      <td>1126798.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2004</td>
      <td>4530729.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2004</td>
      <td>1113662.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2003</td>
      <td>4503491.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2003</td>
      <td>1113083.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2001</td>
      <td>4467634.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2001</td>
      <td>1120409.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2002</td>
      <td>4480089.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2002</td>
      <td>1116590.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>1999</td>
      <td>1121287.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>1999</td>
      <td>4430141.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>total</td>
      <td>2000</td>
      <td>4452173.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Alabama</td>
      <td>AL</td>
      <td>under18</td>
      <td>2000</td>
      <td>1122273.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2514</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>1999</td>
      <td>71946051.0</td>
    </tr>
    <tr>
      <th>2515</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2000</td>
      <td>282162411.0</td>
    </tr>
    <tr>
      <th>2516</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2000</td>
      <td>72376189.0</td>
    </tr>
    <tr>
      <th>2517</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>1999</td>
      <td>279040181.0</td>
    </tr>
    <tr>
      <th>2518</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2001</td>
      <td>284968955.0</td>
    </tr>
    <tr>
      <th>2519</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2001</td>
      <td>72671175.0</td>
    </tr>
    <tr>
      <th>2520</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2002</td>
      <td>287625193.0</td>
    </tr>
    <tr>
      <th>2521</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2002</td>
      <td>72936457.0</td>
    </tr>
    <tr>
      <th>2522</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2003</td>
      <td>290107933.0</td>
    </tr>
    <tr>
      <th>2523</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2003</td>
      <td>73100758.0</td>
    </tr>
    <tr>
      <th>2524</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2004</td>
      <td>292805298.0</td>
    </tr>
    <tr>
      <th>2525</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2004</td>
      <td>73297735.0</td>
    </tr>
    <tr>
      <th>2526</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2005</td>
      <td>295516599.0</td>
    </tr>
    <tr>
      <th>2527</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2005</td>
      <td>73523669.0</td>
    </tr>
    <tr>
      <th>2528</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2006</td>
      <td>298379912.0</td>
    </tr>
    <tr>
      <th>2529</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2006</td>
      <td>73757714.0</td>
    </tr>
    <tr>
      <th>2530</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2007</td>
      <td>301231207.0</td>
    </tr>
    <tr>
      <th>2531</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2007</td>
      <td>74019405.0</td>
    </tr>
    <tr>
      <th>2532</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2008</td>
      <td>304093966.0</td>
    </tr>
    <tr>
      <th>2533</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2008</td>
      <td>74104602.0</td>
    </tr>
    <tr>
      <th>2534</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2013</td>
      <td>73585872.0</td>
    </tr>
    <tr>
      <th>2535</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2013</td>
      <td>316128839.0</td>
    </tr>
    <tr>
      <th>2536</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2009</td>
      <td>306771529.0</td>
    </tr>
    <tr>
      <th>2537</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2009</td>
      <td>74134167.0</td>
    </tr>
    <tr>
      <th>2538</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2010</td>
      <td>74119556.0</td>
    </tr>
    <tr>
      <th>2539</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2010</td>
      <td>309326295.0</td>
    </tr>
    <tr>
      <th>2540</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2011</td>
      <td>73902222.0</td>
    </tr>
    <tr>
      <th>2541</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2011</td>
      <td>311582564.0</td>
    </tr>
    <tr>
      <th>2542</th>
      <td>NaN</td>
      <td>USA</td>
      <td>under18</td>
      <td>2012</td>
      <td>73708179.0</td>
    </tr>
    <tr>
      <th>2543</th>
      <td>NaN</td>
      <td>USA</td>
      <td>total</td>
      <td>2012</td>
      <td>313873685.0</td>
    </tr>
  </tbody>
</table>
<p>2544 rows × 5 columns</p>
</div>




```python
abb_pop.isnull().any(axis=0)
```




    state            True
    state/region    False
    ages            False
    year            False
    population       True
    dtype: bool



去除abbreviation的那一列（axis=1）

查看存在缺失数据的列。

使用.isnull().any()，只有某一列存在一个缺失数据，就会显示True。

查看缺失数据

根据数据是否缺失情况显示数据，如果缺失为True，那么显示

找到有哪些state/region使得state的值为NaN，使用unique()查看非重复值


```python
# abb_pop.isnull().any(axis=1)
abb_pop[abb_pop['state'].isnull()]['state/region'].unique()
```




    array(['PR', 'USA'], dtype=object)




```python
# PR --> PUERTO
# USA --> America
```


```python
# 获取到state/region==PR的副本
abb_pop_PR = abb_pop[abb_pop['state/region'] == 'PR'].copy()
# 对副本进行赋值操作
abb_pop_PR['state'] = 'PUERTO'
# 再把副本的值赋值给原始的表abb_pop
abb_pop[abb_pop['state/region'] == 'PR'] = abb_pop_PR
```


```python
# 获取到state/region==USA的副本
abb_pop_USA = abb_pop[abb_pop['state/region'] == 'USA'].copy()
# 对副本进行赋值操作
abb_pop_USA['state'] = 'America'
# 再把副本的值赋值给原始的表abb_pop
abb_pop[abb_pop['state/region'] == 'USA'] = abb_pop_USA
```

为找到的这些state/region的state项补上正确的值，从而去除掉state这一列的所有NaN！

记住这样清除缺失数据NaN的方法！

合并各州面积数据areas，使用左合并。

思考一下为什么使用外合并？




```python
total = pd.merge(s_ares,abb_pop,how='left')
```


```python
total[total.isnull().any(axis=1)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>area (sq. mi)</th>
      <th>state/region</th>
      <th>ages</th>
      <th>year</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2448</th>
      <td>Puerto Rico</td>
      <td>3515</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
total = total.drop(2448,axis=0)
```


```python
total.isnull().any()
```




    state            False
    area (sq. mi)    False
    state/region     False
    ages             False
    year             False
    population       False
    dtype: bool




```python
pop_density = total['population']/total['area (sq. mi)']
pop_density
```




    0         21.316769
    1         91.897221
    2         21.573851
    3         91.287603
    4         21.474601
    5         91.593900
    6         90.760506
    7         21.635389
    8         21.202163
    9         92.206131
    10        89.137211
    11        21.599222
    12        90.002594
    13        21.649410
    14        87.171757
    15        21.311810
    16        88.300574
    17        21.494344
    18        86.426359
    19        21.243767
    20        85.906778
    21        21.232722
    22        85.222784
    23        21.372470
    24        85.460370
    25        21.299620
    26        21.389218
    27        84.507583
    28        84.927856
    29        21.408027
               ...     
    2418    8360.323529
    2419    1638.279412
    2420    8349.323529
    2421    1614.058824
    2422    8448.588235
    2423    1685.661765
    2424    8428.794118
    2425    1673.852941
    2426    8385.588235
    2427    1691.220588
    2428    8412.441176
    2429    1683.867647
    2430    1674.102941
    2431    8312.235294
    2432    1757.808824
    2433    8349.102941
    2434    1782.500000
    2435    8417.338235
    2436    8537.044118
    2437    1817.941176
    2438    8754.441176
    2439    1771.632353
    2440    1796.617647
    2441    8665.294118
    2442    8836.323529
    2443    1718.014706
    2444    1744.647059
    2445    8787.750000
    2446    1656.352941
    2447    8901.779412
    Length: 2448, dtype: float64




```python
total.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>area (sq. mi)</th>
      <th>state/region</th>
      <th>ages</th>
      <th>year</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>under18</td>
      <td>2012.0</td>
      <td>1117489.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>total</td>
      <td>2012.0</td>
      <td>4817528.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>under18</td>
      <td>2010.0</td>
      <td>1130966.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>total</td>
      <td>2010.0</td>
      <td>4785570.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>under18</td>
      <td>2011.0</td>
      <td>1125763.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>total</td>
      <td>2011.0</td>
      <td>4801627.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>total</td>
      <td>2009.0</td>
      <td>4757938.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>under18</td>
      <td>2009.0</td>
      <td>1134192.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>under18</td>
      <td>2013.0</td>
      <td>1111481.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>total</td>
      <td>2013.0</td>
      <td>4833722.0</td>
    </tr>
  </tbody>
</table>
</div>



继续寻找存在缺失数据的列

我们会发现area(sq.mi)这一列有缺失数据，为了找出是哪一行，我们需要找出是哪个state没有数据

去除含有缺失数据的行

查看数据是否缺失

找出2010年的全民人口数据,df.query(查询语句)


```python
total_2010 = total.query("year==2010.0 & ages == 'total'")
```

对查询结果进行处理，以state列作为新的行索引:set_index


```python
total_2010.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>area (sq. mi)</th>
      <th>state/region</th>
      <th>ages</th>
      <th>year</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>Alabama</td>
      <td>52423</td>
      <td>AL</td>
      <td>total</td>
      <td>2010.0</td>
      <td>4785570.0</td>
    </tr>
    <tr>
      <th>91</th>
      <td>Alaska</td>
      <td>656425</td>
      <td>AK</td>
      <td>total</td>
      <td>2010.0</td>
      <td>713868.0</td>
    </tr>
    <tr>
      <th>101</th>
      <td>Arizona</td>
      <td>114006</td>
      <td>AZ</td>
      <td>total</td>
      <td>2010.0</td>
      <td>6408790.0</td>
    </tr>
    <tr>
      <th>189</th>
      <td>Arkansas</td>
      <td>53182</td>
      <td>AR</td>
      <td>total</td>
      <td>2010.0</td>
      <td>2922280.0</td>
    </tr>
    <tr>
      <th>197</th>
      <td>California</td>
      <td>163707</td>
      <td>CA</td>
      <td>total</td>
      <td>2010.0</td>
      <td>37333601.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
total_2010.set_index('state',inplace=True)
```


```python
density = total_2010['population']/total_2010['area (sq. mi)']
```


```python
density.sort_values(ascending=False).head(5)
```




    state
    District of Columbia    8898.897059
    New Jersey              1009.253268
    Rhode Island             681.339159
    Connecticut              645.600649
    Massachusetts            621.815538
    dtype: float64



计算人口密度。注意是Series/Series，其结果还是一个Series。

排序，并找出人口密度最高的五个州sort_values()

找出人口密度最低的五个州

要点总结：
- 统一用loc()索引
- 善于使用.isnull().any()找到存在NaN的列
- 善于使用.unique()确定该列中哪些key是我们需要的
- 一般使用外合并、左合并，目的只有一个：宁愿该列是NaN也不要丢弃其他列的信息

## 回顾：Series/DataFrame运算与ndarray运算的区别

- Series与DataFrame没有广播，如果对应index没有值，则记为NaN；或者使用add的fill_value来补缺失值
- ndarray有广播，通过重复已有值来计算
